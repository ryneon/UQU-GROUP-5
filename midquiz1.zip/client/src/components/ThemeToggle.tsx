import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <button
      className="theme-toggle"
      type="button"
      aria-label={isDark ? "التبديل إلى الوضع الفاتح" : "التبديل إلى الوضع الداكن"}
      aria-pressed={isDark}
      title={isDark ? "العودة إلى الوضع الفاتح" : "مريح للقراءة ليلًا"}
      onClick={() => toggleTheme?.()}
    >
      <span className="theme-toggle-icon" aria-hidden="true">
        {isDark ? <Sun size={16} /> : <Moon size={16} />}
      </span>
      <span className="theme-toggle-label">{isDark ? "الوضع الفاتح" : "الوضع الداكن"}</span>
    </button>
  );
}
