import { BookOpenCheck, Trophy } from "lucide-react";
import type { ReactNode } from "react";
import { Link } from "wouter";
import ThemeToggle from "./ThemeToggle";

type FeaturePageProps = {
  children: ReactNode;
  className?: string;
};

export default function FeaturePage({ children, className = "" }: FeaturePageProps) {
  return (
    <div className={`site-shell feature-page ${className}`} dir="rtl">
      <header className="masthead screen-only">
        <Link className="brand-mark" href="/" aria-label="العودة إلى الصفحة الرئيسية">
          <span className="brand-icon" aria-hidden="true">
            <BookOpenCheck size={19} strokeWidth={1.8} />
          </span>
          <span>الاستعداد للميد</span>
        </Link>
        <nav className="feature-nav" aria-label="روابط الموقع">
          <Link href="/">المجموعات</Link>
          <Link href="/leaderboard" className="feature-nav-board">
            <Trophy size={14} aria-hidden="true" />
            <span>المتصدرون</span>
          </Link>
          <ThemeToggle />
        </nav>
      </header>
      <main className="feature-main">{children}</main>
      <footer className="site-footer screen-only">
        <span>Made by Abdullah Kurdi using Manus AI</span>
      </footer>
    </div>
  );
}
