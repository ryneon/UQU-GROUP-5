import type { Question } from "./quiz1";

export const assignment1Questions: Question[] = [
  {
    "id": 1,
    "prompt": "Determine if the following system specifications are consistent, and explain your reasoning: \"Access is granted whenever the user pays the fee.\" (p → q). \"The user pays the fee.\" (p). \"Access is denied.\" (¬q).",
    "options": [],
    "essay": true
  },
  {
    "id": 2,
    "prompt": "What is the truth value of the quantification ∀x(x² ≥ x) if the domain consists of all real numbers?",
    "options": [
      {
        "letter": "A",
        "text": "False"
      },
      {
        "letter": "B",
        "text": "True"
      }
    ]
  },
  {
    "id": 3,
    "prompt": "An argument form is considered valid if the truth of all its premises implies that the conclusion is true in every critical row of the truth table.",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 4,
    "prompt": "What is the truth value of ∀x ∃y (x + y = 0) if the domain is all real numbers?",
    "options": [
      {
        "letter": "A",
        "text": "True, because every real number has an additive inverse."
      },
      {
        "letter": "B",
        "text": "True, because x and y can both be 1."
      },
      {
        "letter": "C",
        "text": "False, because x and y must be positive."
      },
      {
        "letter": "D",
        "text": "False, because zero does not have an inverse."
      }
    ]
  },
  {
    "id": 5,
    "prompt": "Determine the truth value of the conditional statement: \"If 1 + 1 = 3, then 2 + 2 = 5.\"",
    "options": [
      {
        "letter": "A",
        "text": "True"
      },
      {
        "letter": "B",
        "text": "False"
      }
    ]
  },
  {
    "id": 6,
    "prompt": "Express the negation of the statement ∀x (x > 1) using quantifiers without using the negation symbol (¬).",
    "options": [
      {
        "letter": "A",
        "text": "∀x (x ≤ 1)"
      },
      {
        "letter": "B",
        "text": "∃x (x ≤ 1)"
      },
      {
        "letter": "C",
        "text": "∃x (x = 1)"
      },
      {
        "letter": "D",
        "text": "∃x (x < 1)"
      }
    ]
  },
  {
    "id": 7,
    "prompt": "Determine the truth value of the following logical expression: ∃n (2n = 3n), where the domain consists of all integers.",
    "options": [
      {
        "letter": "A",
        "text": "True, because n = 1 satisfies the equation."
      },
      {
        "letter": "B",
        "text": "True, because n = 0 satisfies the equation."
      },
      {
        "letter": "C",
        "text": "False, because the domain does not include real numbers."
      },
      {
        "letter": "D",
        "text": "False, because 2n is never equal to 3n."
      }
    ]
  },
  {
    "id": 8,
    "prompt": "Determine the truth value of ∀n (n + 1 > n) if the domain consists of all integers.",
    "options": [
      {
        "letter": "A",
        "text": "Invalid"
      },
      {
        "letter": "B",
        "text": "True"
      },
      {
        "letter": "C",
        "text": "Contingency"
      },
      {
        "letter": "D",
        "text": "False"
      }
    ]
  },
  {
    "id": 9,
    "prompt": "Consider the argument form with premises p → q and p, and conclusion ¬q. According to the truth table method described in the text, is this argument form valid or invalid?",
    "options": [
      {
        "letter": "A",
        "text": "Valid, because the conclusion is true whenever the premises are true."
      },
      {
        "letter": "B",
        "text": "Invalid, because there is a case where the premises are true and the conclusion is false."
      }
    ]
  },
  {
    "id": 10,
    "prompt": "Let g: \"You can graduate,\" m: \"You owe money,\" r: \"You have completed requirements,\" and b: \"You have an overdue book.\"\n\nTranslate the following into a logical expression: \"You can graduate only if you have completed the requirements of your major and you do not owe money to the university, and you do not have an overdue library book.\"",
    "options": [
      {
        "letter": "A",
        "text": "g ↔ (r ∧ ¬m ∧ ¬b)"
      },
      {
        "letter": "B",
        "text": "g → (r ∨ ¬m ∨ ¬b)"
      },
      {
        "letter": "C",
        "text": "g → (r ∧ ¬m ∧ ¬b)"
      },
      {
        "letter": "D",
        "text": "(r ∧ ¬m ∧ ¬b) → g"
      }
    ]
  },
  {
    "id": 11,
    "prompt": "Determine the truth value of ∃n (n = −n) if the domain consists of all integers.",
    "options": [
      {
        "letter": "A",
        "text": "False, because a positive number cannot equal a negative number."
      },
      {
        "letter": "B",
        "text": "True, because n = 0 satisfies the equation."
      },
      {
        "letter": "C",
        "text": "False, because zero is not an integer."
      },
      {
        "letter": "D",
        "text": "True, because n = 1 satisfies the equation."
      }
    ]
  },
  {
    "id": 12,
    "prompt": "What is the logically equivalent negation of the statement: \"All Americans eat cheeseburgers\"?",
    "options": [
      {
        "letter": "A",
        "text": "Some Americans eat cheeseburgers."
      },
      {
        "letter": "B",
        "text": "No Americans eat cheeseburgers."
      },
      {
        "letter": "C",
        "text": "If you are American, you do not eat cheeseburgers."
      },
      {
        "letter": "D",
        "text": "There is an American who does not eat cheeseburgers."
      }
    ]
  },
  {
    "id": 13,
    "prompt": "What is the logically equivalent negation of the statement: \"All Americans eat cheeseburgers\"?",
    "options": [
      {
        "letter": "A",
        "text": "No Americans eat cheeseburgers."
      },
      {
        "letter": "B",
        "text": "There is an American who does not eat cheeseburgers."
      },
      {
        "letter": "C",
        "text": "If you are American, you do not eat cheeseburgers."
      },
      {
        "letter": "D",
        "text": "Some Americans eat cheeseburgers."
      }
    ]
  },
  {
    "id": 14,
    "prompt": "Use De Morgan's laws to find the correct negation of the statement: \"Yoshiko knows Java and calculus.\"",
    "options": [
      {
        "letter": "A",
        "text": "Yoshiko does not know Java and she does not know calculus."
      },
      {
        "letter": "B",
        "text": "If Yoshiko knows Java, then she does not know calculus."
      },
      {
        "letter": "C",
        "text": "Yoshiko knows neither Java nor calculus."
      },
      {
        "letter": "D",
        "text": "Yoshiko does not know Java or she does not know calculus."
      }
    ]
  },
  {
    "id": 15,
    "prompt": "Determine whether the following argument form is valid or invalid: \"If Socrates is human, then Socrates is mortal. Socrates is human. ∴ Socrates is mortal.\"",
    "options": [
      {
        "letter": "A",
        "text": "Invalid"
      },
      {
        "letter": "B",
        "text": "Valid"
      },
      {
        "letter": "C",
        "text": "Consistent"
      },
      {
        "letter": "D",
        "text": "Inconsistent"
      }
    ]
  },
  {
    "id": 16,
    "prompt": "According to De Morgan's laws for quantifiers, which expression is logically equivalent to ¬∃x P(x)?",
    "options": [
      {
        "letter": "A",
        "text": "∀x P(x)"
      },
      {
        "letter": "B",
        "text": "¬∀x P(x)"
      },
      {
        "letter": "C",
        "text": "∀x ¬P(x)"
      },
      {
        "letter": "D",
        "text": "∃x ¬P(x)"
      }
    ]
  },
  {
    "id": 17,
    "prompt": "What is the truth value of the biconditional statement: \"1 + 1 = 3 if and only if monkeys can fly\"?",
    "options": [
      {
        "letter": "A",
        "text": "False"
      },
      {
        "letter": "B",
        "text": "True"
      }
    ]
  },
  {
    "id": 18,
    "prompt": "Let P(x) be the statement \"x = x²\". If the domain consists of the integers, what is the truth value of P(2)?",
    "options": [
      {
        "letter": "A",
        "text": "True"
      },
      {
        "letter": "B",
        "text": "False"
      }
    ]
  },
  {
    "id": 19,
    "prompt": "The logical expression ∀x(x² ≥ x) is true if the domain consists of all integer numbers. Answer True/False.",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 20,
    "prompt": "Explain how to determine the validity of an argument form using a truth table. In your answer, define what a \"critical row\" is and how it determines whether the argument is valid or invalid.",
    "options": [],
    "essay": true
  }
];
