import type { Question } from "./quiz1";

export const quiz2Questions: Question[] = [
  {
    "id": 1,
    "prompt": "What is the truth value of the nested quantification ∀ x ∃ y (x² = y) if the domain consists of all real numbers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 2,
    "prompt": "Let Q(x, y, z) be the statement x + y = z. What is the truth value of ∀ x ∀ y ∃ z Q(x, y, z), where the domain consists of all real numbers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 3,
    "prompt": "According to De Morgan's Laws for Quantifiers, which logical statement is equivalent to the negation of ∃ x (x² = 2)?",
    "options": [
      {
        "letter": "A",
        "text": "∀ x (x² ≠ 2)"
      },
      {
        "letter": "B",
        "text": "∀ x (x² < 2)"
      },
      {
        "letter": "C",
        "text": "∀ x (x² = 2)"
      },
      {
        "letter": "D",
        "text": "∃ x (x² < 2)"
      }
    ]
  },
  {
    "id": 4,
    "prompt": "Let P(x, y) be the statement xy = 1. What is the truth value of ∃ x ∀ y P(x, y) if the domain is all integer numbers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 5,
    "prompt": "What is the truth value of the existential quantification ∃ x (x = x + 1), where the domain consists of all integer numbers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 6,
    "prompt": "What is the truth value of ∀ x ∃ y (x + y = 0) if the domain is all real numbers?",
    "options": [
      {
        "letter": "A",
        "text": "True, because every real number has an additive inverse."
      },
      {
        "letter": "B",
        "text": "False, because x and y must be positive."
      },
      {
        "letter": "C",
        "text": "True, because x and y can both be 1."
      },
      {
        "letter": "D",
        "text": "False, because zero does not have an inverse."
      }
    ]
  },
  {
    "id": 7,
    "prompt": "What is the truth value of the quantification ∀ x (x² > x) if the domain consists of all integers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 8,
    "prompt": "Let Q(x, y, z) be the statement x + y = z. What is the truth value of ∃ z ∀ x ∀ y Q(x, y, z), where the domain consists of all real numbers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 9,
    "prompt": "What is the truth value of ∀ x P(x), where P(x) is the statement x² < 10 and the domain consists of the positive integers not exceeding 4?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 10,
    "prompt": "Let P(x) denote the statement x > 3. What is the truth value of the existential quantification ∃ x P(x) if the domain consists of all real numbers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 11,
    "prompt": "What is the truth value of the quantification ∀ x (x² > x) if the domain consists of all real numbers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 12,
    "prompt": "Translate the statement \"The sum of two positive integers is always positive\" into a logical expression, where the domain for both variables consists of all integers.",
    "options": [
      {
        "letter": "A",
        "text": "∀ x ∀ y ((x > 0) ∧ (y > 0) → (x + y > 0))"
      },
      {
        "letter": "B",
        "text": "∃ x ∃ y ((x > 0) ∧ (y > 0) → (x + y > 0))"
      },
      {
        "letter": "C",
        "text": "∀ x ∀ y ((x > 0) ∨ (y > 0) → (x + y > 0))"
      },
      {
        "letter": "D",
        "text": "∀ x ∃ y ((x > 0) ∧ (y > 0) → (x + y > 0))"
      }
    ]
  },
  {
    "id": 13,
    "prompt": "Consider the argument: \"If George does not have eight legs, then he is not a spider. George is not a spider. Therefore, George has eight legs.\" Determine whether the argument is valid.",
    "options": [
      {
        "letter": "A",
        "text": "Valid"
      },
      {
        "letter": "B",
        "text": "Invalid"
      }
    ]
  },
  {
    "id": 14,
    "prompt": "Consider the argument: \"If it snows, then I will study discrete math. If I study discrete math, I will get an A. Therefore, if it snows, I will get an A.\" Determine whether the argument is valid.",
    "options": [
      {
        "letter": "A",
        "text": "Valid"
      },
      {
        "letter": "B",
        "text": "Invalid"
      }
    ]
  },
  {
    "id": 15,
    "prompt": "Determine the truth value of ∃ n (n = −n) if the domain consists of all integers.",
    "options": [
      {
        "letter": "A",
        "text": "False, because zero is not an integer."
      },
      {
        "letter": "B",
        "text": "True, because n = 0 satisfies the equation."
      },
      {
        "letter": "C",
        "text": "False, because a positive number cannot equal a negative number."
      },
      {
        "letter": "D",
        "text": "True, because n = 1 satisfies the equation."
      }
    ]
  },
  {
    "id": 16,
    "prompt": "Determine the truth value of ∀ n (n + 1 > n) if the domain consists of all integers.",
    "options": [
      {
        "letter": "A",
        "text": "Invalid"
      },
      {
        "letter": "B",
        "text": "False"
      },
      {
        "letter": "C",
        "text": "True"
      },
      {
        "letter": "D",
        "text": "Contingency"
      }
    ]
  },
  {
    "id": 17,
    "prompt": "Let the domain for all variables consist of all real numbers. Which English sentence translates the logical expression ∀ x ∀ y ((x > 0) ∧ (y < 0) → (xy < 0))?",
    "options": [
      {
        "letter": "A",
        "text": "The product of a positive real number and a negative real number is always a negative real number."
      },
      {
        "letter": "B",
        "text": "The sum of a positive real number and a negative real number is always a negative real number."
      },
      {
        "letter": "C",
        "text": "The product of two positive real numbers is always a negative real number."
      },
      {
        "letter": "D",
        "text": "There exists a positive real number and a negative real number whose product is negative."
      }
    ]
  },
  {
    "id": 18,
    "prompt": "Consider the argument: \"I will study discrete math or I will study English literature. I will not study discrete math. Therefore, I will study English literature.\" Determine whether the argument is valid.",
    "options": [
      {
        "letter": "A",
        "text": "Valid"
      },
      {
        "letter": "B",
        "text": "Invalid"
      }
    ]
  },
  {
    "id": 19,
    "prompt": "Let P(x, y) be the statement xy = 1. What is the truth value of ∀ x ∃ y P(x, y) if the domain is all integer numbers?",
    "options": [
      {
        "letter": "",
        "text": "True"
      },
      {
        "letter": "",
        "text": "False"
      }
    ]
  },
  {
    "id": 20,
    "prompt": "Consider the argument: \"If you have a current password, then you can log onto the network. You have a current password. Therefore, you can not log onto the network.\" Determine whether the argument is valid.",
    "options": [
      {
        "letter": "A",
        "text": "Invalid"
      },
      {
        "letter": "B",
        "text": "Valid"
      }
    ]
  }
];
