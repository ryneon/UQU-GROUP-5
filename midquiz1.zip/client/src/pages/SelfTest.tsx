import { useEffect, useState, type FormEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Clock3,
  Medal,
  RefreshCw,
  Sparkles,
  Trophy,
} from "lucide-react";
import { Link } from "wouter";
import FeaturePage from "@/components/FeaturePage";
import { trpc } from "@/lib/trpc";

type ChallengeQuestion = {
  key: string;
  sourceTitle: string;
  prompt: string;
  options: { letter: string; text: string }[];
};

type ChallengeSession = {
  sessionId: string;
  startedAt: string;
  questionCount: number;
  questions: ChallengeQuestion[];
};

type ChallengeResult = {
  displayName: string;
  score: number;
  elapsedSeconds: number;
};

type AnswerFeedback = {
  isCorrect: boolean;
  optionIndex: number;
  correctLetter?: string;
  correctText?: string;
  explanation?: string;
};

function formatDuration(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export default function SelfTest() {
  const [displayName, setDisplayName] = useState(() => {
    try {
      return window.localStorage.getItem("midquiz-practice-name") ?? "";
    } catch {
      return "";
    }
  });
  const [session, setSession] = useState<ChallengeSession | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [feedbackByQuestion, setFeedbackByQuestion] = useState<Record<string, AnswerFeedback>>({});
  const [currentIndex, setCurrentIndex] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [result, setResult] = useState<ChallengeResult | null>(null);
  const startMutation = trpc.practice.start.useMutation();
  const answerMutation = trpc.practice.answer.useMutation();
  const finishMutation = trpc.practice.finish.useMutation();
  const utils = trpc.useUtils();

  useEffect(() => {
    if (!session || result) return;
    const updateTimer = () => {
      setElapsedSeconds(Math.max(0, Math.floor((Date.now() - Date.parse(session.startedAt)) / 1000)));
    };
    updateTimer();
    const timer = window.setInterval(updateTimer, 1000);
    return () => window.clearInterval(timer);
  }, [session, result]);

  async function startTest(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const cleanName = displayName.trim().replace(/\s+/g, " ");
    try {
      const nextSession = await startMutation.mutateAsync({ displayName: cleanName });
      setDisplayName(cleanName);
      setSession(nextSession);
      setAnswers({});
      setFeedbackByQuestion({});
      setCurrentIndex(0);
      setResult(null);
      setElapsedSeconds(0);
      answerMutation.reset();
      finishMutation.reset();
      try {
        window.localStorage.setItem("midquiz-practice-name", cleanName);
      } catch {
        // The leaderboard still stores the name; local prefill is optional.
      }
    } catch {
      // The mutation error is shown in the start form.
    }
  }

  async function submitTest() {
    if (!session || finishMutation.isPending) return;
    if (session.questions.some(question => answers[question.key] === undefined)) return;
    try {
      const finalResult = await finishMutation.mutateAsync({
        sessionId: session.sessionId,
      });
      setResult(finalResult);
      await utils.practice.leaderboard.invalidate();
    } catch {
      // The mutation error is shown with the challenge controls.
    }
  }

  function resetTest() {
    setSession(null);
    setResult(null);
    setAnswers({});
    setFeedbackByQuestion({});
    setCurrentIndex(0);
    setElapsedSeconds(0);
    answerMutation.reset();
    finishMutation.reset();
    startMutation.reset();
  }

  const question = session?.questions[currentIndex];
  const selectedOption = question ? answers[question.key] : undefined;
  const answerFeedback = question ? feedbackByQuestion[question.key] : undefined;
  const answeredCount = session
    ? session.questions.filter(item => answers[item.key] !== undefined).length
    : 0;

  async function selectAnswer(optionIndex: number) {
    if (!session || !question || answers[question.key] !== undefined || answerMutation.isPending) return;
    try {
      const feedback = await answerMutation.mutateAsync({
        sessionId: session.sessionId,
        questionKey: question.key,
        optionIndex,
      });
      setAnswers(current => ({ ...current, [question.key]: feedback.optionIndex }));
      setFeedbackByQuestion(current => ({ ...current, [question.key]: feedback }));
    } catch {
      // Keep the question open if the server could not record this selection.
    }
  }

  return (
    <FeaturePage className="self-test-page">
      <section className="feature-intro" aria-labelledby="self-test-title">
        <span className="feature-kicker">
          <Sparkles size={15} aria-hidden="true" />
          تدريب سريع
        </span>
        <h1 id="self-test-title">اختبر نفسك</h1>
        <p>عشرين سؤالًا عشوائيًا من Quiz 1 وQuiz 2 وAssignment 1.</p>
      </section>

      {!session ? (
        <section className="test-start-card" aria-label="بدء الاختبار">
          <div className="mix-summary" aria-label="توزيع الأسئلة">
            <span><strong>7</strong> Quiz 1</span>
            <span><strong>7</strong> Quiz 2</span>
            <span><strong>6</strong> Assignment 1</span>
          </div>
          <p className="essay-note">الأسئلة المقالية خارج التحدي. إجابة واحدة لكل سؤال؛ يظهر التصحيح فورًا ولا يمكن تبديل الاختيار.</p>
          <form className="name-form" onSubmit={startTest}>
            <label htmlFor="participant-name">اسم مستعار</label>
            <input
              id="participant-name"
              type="text"
              autoComplete="nickname"
              maxLength={32}
              value={displayName}
              onChange={event => setDisplayName(event.target.value)}
              placeholder="اكتب الاسم الذي سيظهر في اللوحة"
              aria-describedby="public-name-note"
              required
            />
            <small id="public-name-note" className="public-name-note">
              سيظهر هذا الاسم مع أفضل نتيجة وزمنك على لوحة عامة؛ الترتيب للتدريب ولا يتحقق من الهوية.
            </small>
            {startMutation.error ? (
              <p className="form-error" role="alert">{startMutation.error.message}</p>
            ) : null}
            <button className="feature-primary-button start-test-button" type="submit" disabled={startMutation.isPending}>
              <span>{startMutation.isPending ? "جارٍ تجهيز الأسئلة…" : "ابدأ الاختبار"}</span>
              <ArrowLeft size={17} aria-hidden="true" />
            </button>
          </form>
          <div className="start-links">
            <Link href="/leaderboard"><Trophy size={15} aria-hidden="true" /> لوحة المتصدرين</Link>
            <span>20 سؤالًا · الدرجة ثم سرعة الحل</span>
          </div>
        </section>
      ) : result ? (
        <section className="challenge-result-card" aria-live="polite">
          <span className="result-emblem"><CheckCircle2 size={28} aria-hidden="true" /></span>
          <span className="result-kicker">اكتملت المحاولة</span>
          <h2>{result.displayName}</h2>
          <div className="result-stats">
            <div><strong>{result.score}<small> / 20</small></strong><span>إجابات صحيحة</span></div>
            <div><strong dir="ltr">{formatDuration(result.elapsedSeconds)}</strong><span>وقت الحل</span></div>
          </div>
          <p className="result-ranking-note">إذا كانت هذه أفضل نتيجتك، ستُحدَّث مرتبتك في لوحة المتصدرين.</p>
          <div className="result-actions">
            <button type="button" className="feature-primary-button" onClick={resetTest}>
              <RefreshCw size={16} aria-hidden="true" />
              <span>محاولة جديدة</span>
            </button>
            <Link className="feature-secondary-button" href="/leaderboard">
              <Medal size={16} aria-hidden="true" />
              <span>عرض المراكز</span>
            </Link>
          </div>
        </section>
      ) : question ? (
        <section className="challenge-card" aria-label="الاختبار العشوائي">
          <div className="challenge-topline">
            <span className="challenge-source">{question.sourceTitle}</span>
            <span className="challenge-timer" dir="ltr"><Clock3 size={15} aria-hidden="true" /> {formatDuration(elapsedSeconds)}</span>
          </div>
          <div className="challenge-progress-meta">
            <span>السؤال {currentIndex + 1} من {session.questionCount}</span>
            <span>{answeredCount} إجابة</span>
          </div>
          <div className="challenge-progress" role="progressbar" aria-label="التقدم في الاختبار" aria-valuemin={0} aria-valuemax={session.questionCount} aria-valuenow={currentIndex + 1}>
            <span style={{ width: `${((currentIndex + 1) / session.questionCount) * 100}%` }} />
          </div>

          <div className="challenge-prompt" lang="en" dir="ltr">
            <span className="challenge-question-number">{String(currentIndex + 1).padStart(2, "0")}</span>
            <p>{question.prompt}</p>
          </div>

          <div className="challenge-options" role="group" aria-label="خيارات الإجابة" lang="en" dir="ltr">
            {question.options.map((option, index) => (
              <button
                className={[
                  "challenge-option",
                  selectedOption === index ? "selected" : "",
                  selectedOption === index && answerFeedback?.isCorrect ? "correct-choice" : "",
                  selectedOption === index && answerFeedback && !answerFeedback.isCorrect ? "wrong-choice" : "",
                  answerFeedback &&
                  !answerFeedback.isCorrect &&
                  option.text === answerFeedback.correctText &&
                  (!answerFeedback.correctLetter || option.letter === answerFeedback.correctLetter)
                    ? "correct-choice"
                    : "",
                ].filter(Boolean).join(" ")}
                type="button"
                key={`${question.key}-${index}`}
                aria-pressed={selectedOption === index}
                disabled={selectedOption !== undefined || answerMutation.isPending}
                onClick={() => void selectAnswer(index)}
              >
                <span className="challenge-option-marker">{option.letter || String.fromCharCode(65 + index)}</span>
                <span>{option.text}</span>
              </button>
            ))}
          </div>

          {answerFeedback ? (
            <div
              className={`instant-feedback ${answerFeedback.isCorrect ? "feedback-correct" : "feedback-incorrect"}`}
              role="status"
              aria-live="polite"
            >
              <span className="instant-feedback-icon" aria-hidden="true">
                {answerFeedback.isCorrect ? <CheckCircle2 size={17} /> : <Sparkles size={17} />}
              </span>
              {answerFeedback.isCorrect ? (
                <p>إجابة صحيحة، ممتاز.</p>
              ) : (
                <p>
                  <strong>الإجابة الصحيحة:</strong>{" "}
                  <bdi dir="ltr">
                    {answerFeedback.correctLetter ? `${answerFeedback.correctLetter}. ` : ""}
                    {answerFeedback.correctText}
                  </bdi>
                  <span className="instant-feedback-separator" aria-hidden="true"> · </span>
                  <span>{answerFeedback.explanation}</span>
                </p>
              )}
            </div>
          ) : null}

          {answerMutation.error ? <p className="form-error" role="alert">{answerMutation.error.message}</p> : null}
          {finishMutation.error ? <p className="form-error" role="alert">{finishMutation.error.message}</p> : null}
          <div className="challenge-controls">
            <button
              className="feature-secondary-button"
              type="button"
              onClick={() => setCurrentIndex(index => Math.max(0, index - 1))}
              disabled={currentIndex === 0 || finishMutation.isPending || answerMutation.isPending}
            >
              <ArrowRight size={16} aria-hidden="true" />
              <span>السابق</span>
            </button>
            {currentIndex < session.questionCount - 1 ? (
              <button
                className="feature-primary-button"
                type="button"
                onClick={() => setCurrentIndex(index => Math.min(session.questionCount - 1, index + 1))}
                disabled={selectedOption === undefined || finishMutation.isPending || answerMutation.isPending}
              >
                <span>التالي</span>
                <ArrowLeft size={16} aria-hidden="true" />
              </button>
            ) : (
              <button
                className="feature-primary-button finish-test-button"
                type="button"
                onClick={submitTest}
                disabled={answeredCount !== session.questionCount || finishMutation.isPending || answerMutation.isPending}
              >
                <span>{finishMutation.isPending ? "جارٍ حساب النتيجة…" : "إنهاء الاختبار"}</span>
                <CheckCircle2 size={16} aria-hidden="true" />
              </button>
            )}
          </div>
        </section>
      ) : null}

      <div className="feature-back-link">
        <Link href="/"><ArrowRight size={15} aria-hidden="true" /> العودة إلى المجموعات</Link>
      </div>
    </FeaturePage>
  );
}
