import { ArrowLeft, Clock3, Medal, Trophy } from "lucide-react";
import { Link } from "wouter";
import FeaturePage from "@/components/FeaturePage";
import { trpc } from "@/lib/trpc";

function formatDuration(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

export default function Leaderboard() {
  const results = trpc.practice.leaderboard.useQuery(undefined, {
    refetchInterval: 20_000,
  });

  return (
    <FeaturePage className="leaderboard-page">
      <section className="feature-intro" aria-labelledby="leaderboard-title">
        <span className="feature-kicker">
          <Trophy size={15} aria-hidden="true" />
          أفضل المحاولات
        </span>
        <h1 id="leaderboard-title">لوحة المتصدرين</h1>
        <p>الترتيب حسب الإجابات الصحيحة، ثم الأسرع عند التعادل.</p>
      </section>

      <section className="leaderboard-card" aria-label="ترتيب المشاركين">
        <div className="leaderboard-header" aria-hidden="true">
          <span>المركز</span>
          <span>الاسم</span>
          <span>الصحيح</span>
          <span>الوقت</span>
        </div>

        {results.isLoading ? (
          <p className="leaderboard-message" role="status">جارٍ تحميل الترتيب…</p>
        ) : results.error ? (
          <p className="leaderboard-message error-message" role="alert">
            تعذّر تحميل لوحة المتصدرين الآن. حاول تحديث الصفحة.
          </p>
        ) : results.data?.length ? (
          <ol className="leaderboard-list">
            {results.data.map((entry, index) => (
              <li className={`leaderboard-row${index < 3 ? ` podium podium-${index + 1}` : ""}`} key={`${entry.displayName}-${index}`}>
                <span className="leaderboard-rank" dir="ltr">
                  {index < 3 ? <Medal size={17} aria-hidden="true" /> : null}
                  <span>{String(index + 1).padStart(2, "0")}</span>
                </span>
                <span className="leaderboard-name">{entry.displayName}</span>
                <span className="leaderboard-score" dir="ltr">
                  {entry.bestScore}<small>/20</small>
                </span>
                <span className="leaderboard-time" dir="ltr">
                  <Clock3 size={13} aria-hidden="true" />
                  {formatDuration(entry.bestElapsedSeconds)}
                </span>
              </li>
            ))}
          </ol>
        ) : (
          <div className="leaderboard-empty">
            <span className="empty-trophy"><Trophy size={24} aria-hidden="true" /></span>
            <strong>لا توجد نتائج بعد</strong>
            <span>ابدأ أول محاولة وأضف اسمك إلى الترتيب.</span>
          </div>
        )}
      </section>

      <div className="leaderboard-bottom">
        <span>تظهر أفضل نتيجة مسجلة لكل اسم مستعار.</span>
        <Link className="feature-primary-button" href="/challenge">
          <span>اختبر نفسك</span>
          <ArrowLeft size={17} aria-hidden="true" />
        </Link>
      </div>
    </FeaturePage>
  );
}
