import { ArrowLeft, MessageCircle } from "lucide-react";
import { Link } from "wouter";
import FeaturePage from "@/components/FeaturePage";

const studentStories = [
  "الاختبار جا نفس الكويزات والاسايمنت بالضبط",
  "نفس الكويزات والواجب نسخ لصق",
  "الاختبار مافيه مقالي وأغلبه خيارات True و False",
];

export default function StudentStories() {
  return (
    <FeaturePage className="stories-page">
      <section className="feature-intro" aria-labelledby="stories-title">
        <span className="feature-kicker">
          <MessageCircle size={15} aria-hidden="true" />
          تجارب سابقة
        </span>
        <h1 id="stories-title">كلام الطلاب الي اختبروا قبلنا</h1>
        <p className="stories-disclaimer">
          تجارب منقولة عن طلاب، وليست ضمانًا لمحتوى الاختبار.
        </p>
      </section>

      <section className="story-bubbles" aria-label="اقتباسات مجهولة من الطلاب">
        {studentStories.map((story, index) => (
          <article className={`story-bubble story-bubble-${index + 1}`} key={story}>
            <blockquote>{story}</blockquote>
            <footer>
              <span className="anonymous-avatar" aria-hidden="true">؟</span>
              <cite>مجهول</cite>
            </footer>
          </article>
        ))}
      </section>

      <div className="stories-cta">
        <Link className="feature-primary-button" href="/challenge">
          <span>اختبر نفسك</span>
          <ArrowLeft size={17} aria-hidden="true" />
        </Link>
      </div>
    </FeaturePage>
  );
}
