import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Calculator,
  CheckCircle2,
  Clock3,
  Home,
  RefreshCw,
} from "lucide-react";
import { Link } from "wouter";
import FeaturePage from "@/components/FeaturePage";
import { trpc } from "@/lib/trpc";

const TEST_DURATION_SECONDS = 60 * 60;

type EstimateQuestion = {
  key: string;
  sourceTitle: string;
  prompt: string;
  options: { letter: string; text: string }[];
};

type EstimateSession = {
  sessionId: string;
  startedAt: string;
  questionCount: number;
  questions: EstimateQuestion[];
};

type EstimateResult = {
  score: number;
  elapsedSeconds: number;
  questionCount: number;
};

function formatClock(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export default function GradeEstimate() {
  const [session, setSession] = useState<EstimateSession | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [currentIndex, setCurrentIndex] = useState(0);
  const [secondsRemaining, setSecondsRemaining] = useState(TEST_DURATION_SECONDS);
  const [result, setResult] = useState<EstimateResult | null>(null);
  const finishStarted = useRef(false);
  const timeoutHandled = useRef(false);

  const startMutation = trpc.practice.startEstimate.useMutation();
  const answerMutation = trpc.practice.answerEstimate.useMutation();
  const finishMutation = trpc.practice.finishEstimate.useMutation();

  async function finishTest(isTimeout = false) {
    if (!session || finishStarted.current || result) return;
    if (!isTimeout && session.questions.some(question => answers[question.key] === undefined)) return;

    finishStarted.current = true;
    try {
      const finalResult = await finishMutation.mutateAsync({ sessionId: session.sessionId });
      setResult(finalResult);
    } catch {
      finishStarted.current = false;
    }
  }

  useEffect(() => {
    if (!session || result) return;

    const updateTimer = () => {
      const deadline = Date.parse(session.startedAt) + TEST_DURATION_SECONDS * 1000;
      const remaining = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
      setSecondsRemaining(remaining);
      if (remaining === 0 && !timeoutHandled.current) {
        timeoutHandled.current = true;
        void finishTest(true);
      }
    };

    updateTimer();
    const timer = window.setInterval(updateTimer, 1000);
    return () => window.clearInterval(timer);
  }, [session, result]);

  async function startTest() {
    try {
      const nextSession = await startMutation.mutateAsync();
      setSession(nextSession);
      setAnswers({});
      setCurrentIndex(0);
      setSecondsRemaining(TEST_DURATION_SECONDS);
      setResult(null);
      finishStarted.current = false;
      timeoutHandled.current = false;
      answerMutation.reset();
      finishMutation.reset();
    } catch {
      // The start error is shown with the start button.
    }
  }

  async function selectAnswer(optionIndex: number) {
    if (!session || !question || selectedOption !== undefined || answerMutation.isPending || secondsRemaining === 0) return;
    try {
      const recorded = await answerMutation.mutateAsync({
        sessionId: session.sessionId,
        questionKey: question.key,
        optionIndex,
      });
      setAnswers(current => ({ ...current, [question.key]: recorded.optionIndex }));
    } catch {
      // Leave the question open if the server could not save the choice.
    }
  }

  function resetTest() {
    setSession(null);
    setAnswers({});
    setCurrentIndex(0);
    setSecondsRemaining(TEST_DURATION_SECONDS);
    setResult(null);
    finishStarted.current = false;
    timeoutHandled.current = false;
    startMutation.reset();
    answerMutation.reset();
    finishMutation.reset();
  }

  const question = session?.questions[currentIndex];
  const selectedOption = question ? answers[question.key] : undefined;
  const answeredCount = session
    ? session.questions.filter(item => answers[item.key] !== undefined).length
    : 0;
  const allAnswered = Boolean(session && answeredCount === session.questionCount);
  const percentage = result ? Math.round((result.score / result.questionCount) * 100) : 0;

  return (
    <FeaturePage className="grade-estimate-page">
      <section className="feature-intro" aria-labelledby="grade-estimate-title">
        <span className="feature-kicker">
          <Calculator size={15} aria-hidden="true" />
          محاكاة تدريبية
        </span>
        <h1 id="grade-estimate-title">احسب درجتي التقريبية</h1>
        <p>20 سؤالًا موضوعيًا من المجموعات الثلاث، بوقت أقصاه ساعة كاملة.</p>
      </section>

      {!session ? (
        <section className="test-start-card" aria-label="بدء الاختبار التجريبي">
          <div className="mix-summary" aria-label="توزيع الأسئلة">
            <span><strong>7</strong> Quiz 1</span>
            <span><strong>7</strong> Quiz 2</span>
            <span><strong>6</strong> Assignment 1</span>
          </div>
          <p className="essay-note">
            الاختبار عشوائي، ولا يشمل السؤالين المقاليين. لا تعرض المحاكاة الإجابات أثناء المحاولة؛ عند انتهاء الساعة تُحتسب الأسئلة غير المجاب عنها خطأً.
          </p>
          {startMutation.error ? <p className="form-error" role="alert">{startMutation.error.message}</p> : null}
          <button
            className="feature-primary-button start-test-button"
            type="button"
            onClick={() => void startTest()}
            disabled={startMutation.isPending}
          >
            <span>{startMutation.isPending ? "جارٍ تجهيز الأسئلة…" : "ابدأ الاختبار التجريبي"}</span>
            <ArrowLeft size={17} aria-hidden="true" />
          </button>
          <p className="estimate-private-note">النتيجة تقديرية للتدريب ولا تُضاف إلى لوحة المتصدرين.</p>
        </section>
      ) : result ? (
        <section className="challenge-result-card estimate-result-card" aria-live="polite">
          <span className="result-emblem"><CheckCircle2 size={28} aria-hidden="true" /></span>
          <span className="result-kicker">اكتملت المحاكاة</span>
          <h2>درجتك التقريبية</h2>
          <div className="result-stats estimate-result-stats">
            <div><strong>{result.score}<small> / {result.questionCount}</small></strong><span>إجابات صحيحة</span></div>
            <div><strong dir="ltr">{percentage}%</strong><span>نسبة تقديرية</span></div>
            <div><strong dir="ltr">{formatClock(result.elapsedSeconds)}</strong><span>وقت الحل</span></div>
          </div>
          <p className="result-ranking-note">هذه نسبة تدريبية من الأسئلة الموضوعية وليست درجة نهائية، ولا تدخل في لوحة المتصدرين.</p>
          <div className="result-actions">
            <button type="button" className="feature-primary-button" onClick={resetTest}>
              <RefreshCw size={16} aria-hidden="true" />
              <span>محاولة جديدة</span>
            </button>
            <Link className="feature-secondary-button" href="/">
              <Home size={16} aria-hidden="true" />
              <span>العودة للمجموعات</span>
            </Link>
          </div>
        </section>
      ) : question ? (
        <section className="challenge-card estimate-challenge-card" aria-label="الاختبار التجريبي">
          <div className="challenge-topline">
            <span className="challenge-source">{question.sourceTitle}</span>
            <span className={`challenge-timer estimate-timer ${secondsRemaining <= 300 ? "time-warning" : ""}`} dir="ltr">
              <Clock3 size={15} aria-hidden="true" /> {formatClock(secondsRemaining)}
            </span>
          </div>
          <div className="challenge-progress-meta">
            <span>السؤال {currentIndex + 1} من {session.questionCount}</span>
            <span>{answeredCount} إجابة محفوظة</span>
          </div>
          <div className="challenge-progress" role="progressbar" aria-label="التقدم في الاختبار التجريبي" aria-valuemin={0} aria-valuemax={session.questionCount} aria-valuenow={currentIndex + 1}>
            <span style={{ width: `${((currentIndex + 1) / session.questionCount) * 100}%` }} />
          </div>
          <div className="challenge-prompt" lang="en" dir="ltr">
            <span className="challenge-question-number">{String(currentIndex + 1).padStart(2, "0")}</span>
            <p>{question.prompt}</p>
          </div>
          <div className="challenge-options" role="group" aria-label="خيارات الإجابة" lang="en" dir="ltr">
            {question.options.map((option, index) => (
              <button
                className={`challenge-option ${selectedOption === index ? "selected" : ""}`}
                type="button"
                key={`${question.key}-${index}`}
                aria-pressed={selectedOption === index}
                disabled={selectedOption !== undefined || answerMutation.isPending || secondsRemaining === 0}
                onClick={() => void selectAnswer(index)}
              >
                <span className="challenge-option-marker">{option.letter || String.fromCharCode(65 + index)}</span>
                <span>{option.text}</span>
              </button>
            ))}
          </div>
          {answerMutation.error ? <p className="form-error" role="alert">{answerMutation.error.message}</p> : null}
          {finishMutation.error ? (
            <div className="estimate-finish-error" role="alert">
              <p>{finishMutation.error.message}</p>
              <button className="feature-secondary-button" type="button" onClick={() => void finishTest(secondsRemaining === 0)}>
                إعادة محاولة إنهاء الاختبار
              </button>
            </div>
          ) : null}
          {secondsRemaining === 0 && finishMutation.isPending ? (
            <p className="estimate-expired-note" role="status">انتهى الوقت؛ جارٍ حساب الأسئلة غير المجابة كإجابات خاطئة.</p>
          ) : null}
          <div className="challenge-controls">
            <button
              className="feature-secondary-button"
              type="button"
              onClick={() => setCurrentIndex(index => Math.max(0, index - 1))}
              disabled={currentIndex === 0 || finishMutation.isPending || answerMutation.isPending}
            >
              <ArrowRight size={16} aria-hidden="true" />
              <span>السابق</span>
            </button>
            {allAnswered ? (
              <button
                className="feature-primary-button finish-test-button"
                type="button"
                onClick={() => void finishTest()}
                disabled={finishMutation.isPending || answerMutation.isPending}
              >
                <span>{finishMutation.isPending ? "جارٍ حساب النسبة…" : "إنهاء وحساب النسبة"}</span>
                <CheckCircle2 size={16} aria-hidden="true" />
              </button>
            ) : (
              <button
                className="feature-primary-button"
                type="button"
                onClick={() => setCurrentIndex(index => Math.min(session.questionCount - 1, index + 1))}
                disabled={selectedOption === undefined || currentIndex >= session.questionCount - 1 || finishMutation.isPending || answerMutation.isPending}
              >
                <span>التالي</span>
                <ArrowLeft size={16} aria-hidden="true" />
              </button>
            )}
          </div>
          <p className="estimate-progress-note">لا يمكن إنهاء المحاولة مبكرًا قبل الإجابة عن جميع الأسئلة.</p>
        </section>
      ) : null}

      <div className="feature-back-link">
        <Link href="/"><ArrowRight size={15} aria-hidden="true" /> العودة إلى المجموعات</Link>
      </div>
    </FeaturePage>
  );
}
