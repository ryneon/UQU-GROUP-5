import { useEffect, useState } from "react";
import {
  BookOpenCheck,
  Calculator,
  CalendarDays,
  Download,
  FileText,
  MessageCircle,
  MoveLeft,
  Trophy,
  Zap,
} from "lucide-react";
import { Link } from "wouter";
import ThemeToggle from "@/components/ThemeToggle";

const quizChoices = [
  { key: "quiz1", title: "Quiz 1", number: "01", route: "/quiz1" },
  { key: "quiz2", title: "Quiz 2", number: "02", route: "/quiz2" },
  { key: "assignment1", title: "Assignment 1", number: "03", route: "/assignment1" },
];

const EXAM_START = Date.parse("2026-10-13T14:00:00+03:00");
const EXAM_END = Date.parse("2026-10-13T15:00:00+03:00");

function countdownParts(milliseconds: number) {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  const days = Math.floor(totalSeconds / 86_400);
  const hours = Math.floor((totalSeconds % 86_400) / 3_600);
  const minutes = Math.floor((totalSeconds % 3_600) / 60);
  const seconds = totalSeconds % 60;
  return [
    { value: String(days).padStart(2, "0"), label: "يوم" },
    { value: String(hours).padStart(2, "0"), label: "ساعة" },
    { value: String(minutes).padStart(2, "0"), label: "دقيقة" },
    { value: String(seconds).padStart(2, "0"), label: "ثانية" },
  ];
}

export default function Home() {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const examState = now < EXAM_START ? "upcoming" : now < EXAM_END ? "running" : "ended";
  const countdownTarget = examState === "upcoming" ? EXAM_START : EXAM_END;
  const remaining = countdownParts(countdownTarget - now);

  return (
    <div className="site-shell landing-page" dir="rtl">
      <header className="masthead">
        <Link className="brand-mark" href="/" aria-label="الصفحة الرئيسية">
          <span className="brand-icon" aria-hidden="true">
            <BookOpenCheck size={19} strokeWidth={1.8} />
          </span>
          <span>مراجعة الهياكل المتقطعة</span>
        </Link>
        <div className="masthead-actions">
          <ThemeToggle />
          <Link className="leaderboard-link" href="/leaderboard">
            <Trophy size={15} aria-hidden="true" />
            <span>لوحة المتصدرين</span>
          </Link>
        </div>
      </header>

      <main>
        <section className="hero-card" aria-labelledby="page-title">
          <div className="hero-copy">
            <h1 id="page-title">
              الاستعداد لاختبار الميد
              <span>للهياكل المتقطعة ١</span>
            </h1>
            <p className="class-section">الموقع مخصص للشعبة ٥</p>
            <p className="credit">Made by Abdullah Kurdi using Manus AI</p>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="hero-orbit orbit-one" />
            <div className="hero-orbit orbit-two" />
            <div className="formula-card">
              <span className="formula-label">STUDY NOTES</span>
              <span className="formula-primary">∀ x <i>∃</i> y</span>
              <span className="formula-rule" />
              <span className="formula-secondary">p <i>→</i> q</span>
            </div>
            <span className="hero-spark spark-one" />
            <span className="hero-spark spark-two" />
          </div>
        </section>

        <section className="exam-schedule" aria-labelledby="exam-schedule-title">
          <div className="exam-date-info">
            <span className="exam-date-icon" aria-hidden="true"><CalendarDays size={19} /></span>
            <div className="exam-date-copy">
              <span className="exam-date-caption" id="exam-schedule-title">موعد الاختبار</span>
              <time dateTime="2026-10-13T14:00:00+03:00">
                <strong>الثلاثاء، 13 أكتوبر 2026</strong>
                <span>من 2:00 ظهرًا إلى 3:00 عصرًا · بتوقيت الرياض</span>
              </time>
            </div>
          </div>
          <div className={`exam-countdown exam-countdown-${examState}`} aria-live="off">
            <span className="exam-countdown-label">
              {examState === "upcoming" ? "العدّ التنازلي للاختبار" : examState === "running" ? "الاختبار جارٍ الآن · ينتهي بعد" : "حالة الموعد"}
            </span>
            {examState === "ended" ? (
              <strong className="exam-ended-message">انتهى موعد الاختبار</strong>
            ) : (
              <div className="exam-countdown-values" aria-label={examState === "running" ? "الوقت المتبقي لانتهاء الاختبار" : "الوقت المتبقي لبداية الاختبار"}>
                {remaining.map(part => (
                  <span className="exam-countdown-unit" key={part.label}>
                    <strong dir="ltr">{part.value}</strong>
                    <small>{part.label}</small>
                  </span>
                ))}
              </div>
            )}
          </div>
        </section>

        <section className="quiz-picker" aria-labelledby="quiz-picker-title">
          <div className="picker-heading">
            <h2 id="quiz-picker-title">اختر المجموعة</h2>
            <span className="picker-count">٣ مجموعات</span>
          </div>

          <div className="quiz-choice-list">
            {quizChoices.map(quiz => (
              <article className={`quiz-choice-card ${quiz.key}`} key={quiz.key}>
                <div className="choice-number" aria-hidden="true">{quiz.number}</div>
                <div className="choice-actions">
                  <Link className="choose-quiz" href={quiz.route}>
                    <span>{quiz.title}</span>
                    <MoveLeft size={17} aria-hidden="true" />
                  </Link>
                  <a className="export-link" href={`${quiz.route}?export=pdf`}>
                    <Download size={15} aria-hidden="true" />
                    <span>Export as PDF</span>
                  </a>
                  <span className="export-note">يفتح نافذة الطباعة للحفظ بصيغة PDF</span>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="grade-estimate-promo" aria-label="حساب الدرجة التقريبية">
          <Link className="practice-shortcut grade-estimate-shortcut" href="/grade-estimate">
            <span className="shortcut-icon grade-estimate-icon" aria-hidden="true"><Calculator size={20} /></span>
            <span className="shortcut-copy">
              <strong>احسب درجتي التقريبية</strong>
              <small>اختبار تجريبي · 20 سؤالًا · 60 دقيقة</small>
            </span>
            <MoveLeft size={17} aria-hidden="true" />
          </Link>
        </section>

        <section className="practice-shortcuts" aria-label="خيارات إضافية">
          <Link className="practice-shortcut stories-shortcut" href="/student-stories">
            <span className="shortcut-icon" aria-hidden="true"><MessageCircle size={20} /></span>
            <span className="shortcut-copy"><strong>كلام الطلاب الي اختبروا قبلنا</strong></span>
            <MoveLeft size={17} aria-hidden="true" />
          </Link>
          <Link className="practice-shortcut challenge-shortcut" href="/challenge">
            <span className="shortcut-icon" aria-hidden="true"><Zap size={20} /></span>
            <span className="shortcut-copy"><strong>اختبر نفسك</strong></span>
            <MoveLeft size={17} aria-hidden="true" />
          </Link>
        </section>
      </main>

      <footer className="site-footer">
        <span className="footer-mark"><FileText size={15} aria-hidden="true" /></span>
        <span>الاستعداد لاختبار الميد للهياكل المتقطعة ١</span>
        <span className="footer-separator" aria-hidden="true">·</span>
        <span className="footer-note">Quiz 1 · Quiz 2 · Assignment 1</span>
      </footer>
    </div>
  );
}
