import { useEffect, useState } from "react";
import {
  ArrowRight,
  BookOpenCheck,
  Check,
  Download,
  Eye,
  FileText,
  Lightbulb,
} from "lucide-react";
import { Link } from "wouter";
import ThemeToggle from "@/components/ThemeToggle";
import { quiz1Questions, type Question } from "@/data/quiz1";
import { quiz2Questions } from "@/data/quiz2";
import { assignment1Questions } from "@/data/assignment1";
import { trpc } from "@/lib/trpc";

type QuizKey = "quiz1" | "quiz2" | "assignment1";
type QuizQuestion = Question & { essay?: boolean };
type ReviewAnswer = { correctLetter: string; correctText: string; explanation: string };

type QuizDefinition = {
  title: string;
  questions: QuizQuestion[];
  previous?: { label: string; href: string };
  next?: { label: string; href: string };
};

const quizDefinitions: Record<QuizKey, QuizDefinition> = {
  quiz1: {
    title: "Quiz 1",
    questions: quiz1Questions,
    next: { label: "Quiz 2", href: "/quiz2" },
  },
  quiz2: {
    title: "Quiz 2",
    questions: quiz2Questions,
    previous: { label: "Quiz 1", href: "/quiz1" },
    next: { label: "Assignment 1", href: "/assignment1" },
  },
  assignment1: {
    title: "Assignment 1",
    questions: assignment1Questions,
    previous: { label: "Quiz 2", href: "/quiz2" },
  },
};

export default function QuizPage({ quizKey }: { quizKey: QuizKey }) {
  const quiz = quizDefinitions[quizKey];
  const [revealed, setRevealed] = useState<Record<number, ReviewAnswer>>({});
  const [loadingQuestionId, setLoadingQuestionId] = useState<number | null>(null);
  const [answerErrorId, setAnswerErrorId] = useState<number | null>(null);
  const answerMutation = trpc.practice.revealAnswer.useMutation();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("export") !== "pdf") return;

    const timeout = window.setTimeout(() => {
      window.history.replaceState(null, "", window.location.pathname);
      window.print();
    }, 450);
    return () => window.clearTimeout(timeout);
  }, [quizKey]);

  async function toggleAnswer(questionId: number) {
    if (revealed[questionId]) {
      setRevealed(current => {
        const next = { ...current };
        delete next[questionId];
        return next;
      });
      setAnswerErrorId(null);
      return;
    }
    setLoadingQuestionId(questionId);
    setAnswerErrorId(null);
    try {
      const answer = await answerMutation.mutateAsync({ source: quizKey, questionId });
      setRevealed(current => ({ ...current, [questionId]: answer }));
    } catch {
      setAnswerErrorId(questionId);
    } finally {
      setLoadingQuestionId(null);
    }
  }

  return (
    <div className="site-shell quiz-page" dir="rtl">
      <header className="masthead screen-only">
        <Link className="brand-mark" href="/" aria-label="العودة إلى الصفحة الرئيسية">
          <span className="brand-icon" aria-hidden="true">
            <BookOpenCheck size={19} strokeWidth={1.8} />
          </span>
          <span>مراجعة الهياكل المتقطعة</span>
        </Link>
        <div className="masthead-actions">
          <ThemeToggle />
          <Link className="back-link" href="/">
            <ArrowRight size={15} aria-hidden="true" />
            <span>العودة إلى المجموعات</span>
          </Link>
        </div>
      </header>

      <main className="quiz-main">
        <section className="quiz-page-heading screen-only" aria-labelledby="quiz-title">
          <div>
            <h1 id="quiz-title">{quiz.title}</h1>
            <p>{quiz.questions.length} سؤالًا <span aria-hidden="true">·</span> اكشف الإجابة بعد المحاولة</p>
          </div>
          <div className="quiz-export-area">
            <button className="export-button" type="button" onClick={() => window.print()}>
              <Download size={16} aria-hidden="true" />
              <span>Export as PDF</span>
            </button>
            <span className="export-note">في نافذة الطباعة اختر «حفظ كـ PDF»</span>
          </div>
        </section>

        <div className="print-heading" dir="rtl">
          <span>الاستعداد لاختبار الميد للهياكل المتقطعة ١</span>
          <strong>{quiz.title}</strong>
          <small>{quiz.questions.length} سؤالًا</small>
        </div>

        <section className="question-list" aria-label={quiz.title}>
          {quiz.questions.map(question => {
            const answer = revealed[question.id];
            const isRevealed = Boolean(answer);
            const isLoading = loadingQuestionId === question.id;
            const number = String(question.id).padStart(2, "0");

            return (
              <article className={`question-card${question.essay ? " essay-question" : ""}`} key={`${quizKey}-${question.id}`}>
                <div className="question-heading">
                  <span className="question-number">{number}</span>
                  <span className="question-label">السؤال {question.id}</span>
                  {question.essay ? <span className="essay-badge">مقالي</span> : null}
                  <span className="question-mark" aria-hidden="true"><BookOpenCheck size={16} /></span>
                </div>

                <div className="question-body" lang="en" dir="ltr">
                  <p className="question-prompt">{question.prompt}</p>
                  {question.options.length > 0 ? (
                    <ol className="option-list" aria-label={`Options for question ${question.id}`}>
                      {question.options.map(option => (
                        <li className="option-row" key={`${option.letter}-${option.text}`}>
                          <span className={`option-letter${option.letter ? "" : " option-dash"}`}>
                            {option.letter ? `${option.letter}.` : "–"}
                          </span>
                          <span className="option-text">{option.text}</span>
                        </li>
                      ))}
                    </ol>
                  ) : null}
                </div>

                {question.essay ? (
                  <div className="essay-entry screen-only" dir="rtl">
                    <label htmlFor={`essay-${quizKey}-${question.id}`}>مساحة الإجابة</label>
                    <textarea
                      id={`essay-${quizKey}-${question.id}`}
                      rows={4}
                      placeholder="اكتب إجابتك هنا..."
                      aria-label={`مساحة الإجابة للسؤال ${question.id}`}
                    />
                  </div>
                ) : null}
                {question.essay ? (
                  <div className="essay-writing-area" aria-hidden="true">
                    <span>مساحة الإجابة</span>
                    <i /><i /><i /><i />
                  </div>
                ) : null}

                <button
                  className={`reveal-button${isRevealed ? " is-open" : ""} screen-only`}
                  type="button"
                  aria-expanded={isRevealed}
                  aria-controls={`answer-${quizKey}-${question.id}`}
                  disabled={loadingQuestionId !== null}
                  aria-busy={isLoading}
                  onClick={() => void toggleAnswer(question.id)}
                >
                  {isRevealed ? <Check size={15} aria-hidden="true" /> : <Eye size={15} aria-hidden="true" />}
                  <span>{isLoading ? "جارٍ تحميل الإجابة…" : isRevealed ? "إخفاء الإجابة" : "تظهر الإجابة"}</span>
                </button>

                {answerErrorId === question.id ? (
                  <p className="form-error reveal-error screen-only" role="alert">تعذّر تحميل الإجابة. حاول مرة أخرى.</p>
                ) : null}

                <div
                  className="answer-panel screen-only"
                  id={`answer-${quizKey}-${question.id}`}
                  hidden={!isRevealed}
                  role="region"
                  aria-label={`الإجابة الصحيحة للسؤال ${question.id}`}
                  lang="en"
                  dir="ltr"
                >
                  <div className="answer-title">
                    <span className="answer-check"><Check size={13} aria-hidden="true" /></span>
                    <span>Correct answer</span>
                  </div>
                  <p className="answer-choice">
                    {answer?.correctLetter ? <strong>{answer.correctLetter}. </strong> : null}
                    {answer?.correctText}
                  </p>
                  <p className="answer-explanation" lang="ar" dir="rtl">
                    <Lightbulb size={15} aria-hidden="true" />
                    <span>{answer?.explanation}</span>
                  </p>
                </div>
              </article>
            );
          })}
        </section>

        <nav className="quiz-bottom-nav screen-only" aria-label="التنقل بين المجموعات">
          <Link className="bottom-nav-link secondary" href="/">
            العودة إلى المجموعات
          </Link>
          {quiz.previous ? (
            <Link className="bottom-nav-link secondary" href={quiz.previous.href}>{quiz.previous.label}</Link>
          ) : null}
          {quiz.next ? (
            <Link className="bottom-nav-link primary" href={quiz.next.href}>
              {quiz.next.label}
              <ArrowRight size={15} aria-hidden="true" />
            </Link>
          ) : null}
        </nav>
      </main>

      <footer className="site-footer screen-only">
        <span className="footer-mark"><FileText size={15} aria-hidden="true" /></span>
        <span>Made by Abdullah Kurdi using Manus AI</span>
      </footer>
    </div>
  );
}
