import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Leaderboard from "./pages/Leaderboard";
import QuizPage from "./pages/QuizPage";
import SelfTest from "./pages/SelfTest";
import StudentStories from "./pages/StudentStories";
import GradeEstimate from "./pages/GradeEstimate";

function Quiz1Page() {
  return <QuizPage quizKey="quiz1" />;
}

function Quiz2Page() {
  return <QuizPage quizKey="quiz2" />;
}

function Assignment1Page() {
  return <QuizPage quizKey="assignment1" />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/quiz1" component={Quiz1Page} />
      <Route path="/quiz2" component={Quiz2Page} />
      <Route path="/assignment1" component={Assignment1Page} />
      <Route path="/student-stories" component={StudentStories} />
      <Route path="/challenge" component={SelfTest} />
      <Route path="/grade-estimate" component={GradeEstimate} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
