import { writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { assignment1Questions } from "../server/data/assignment1";
import { quiz1Questions } from "../server/data/quiz1";
import { quiz2Questions } from "../server/data/quiz2";

 type PublicQuestion = {
  id: number;
  prompt: string;
  options: { letter: string; text: string }[];
  essay?: boolean;
};

type SourceQuestion = {
  id: number;
  prompt: string;
  options: { letter: string; text: string }[];
  essay?: boolean;
  correctLetter: string;
  correctText: string;
  explanation: string;
};

function publicQuestions(source: SourceQuestion[]): PublicQuestion[] {
  return source.map(({ id, prompt, options, essay }) => ({
    id,
    prompt,
    options,
    ...(essay ? { essay: true } : {}),
  }));
}

function renderModule(exportName: string, questions: PublicQuestion[], includeTypes = false): string {
  const typeDeclarations = includeTypes
    ? `export type Option = { letter: string; text: string };\n\nexport type Question = {\n  id: number;\n  prompt: string;\n  options: Option[];\n  essay?: boolean;\n};\n\n`
    : `import type { Question } from "./quiz1";\n\n`;
  const itemType = includeTypes ? "Question" : "Question";
  return `${typeDeclarations}export const ${exportName}: ${itemType}[] = ${JSON.stringify(questions, null, 2)};\n`;
}

const outputs = [
  {
    file: "client/src/data/quiz1.ts",
    module: renderModule("quiz1Questions", publicQuestions(quiz1Questions as SourceQuestion[]), true),
  },
  {
    file: "client/src/data/quiz2.ts",
    module: renderModule("quiz2Questions", publicQuestions(quiz2Questions as SourceQuestion[])),
  },
  {
    file: "client/src/data/assignment1.ts",
    module: renderModule("assignment1Questions", publicQuestions(assignment1Questions as SourceQuestion[])),
  },
];

for (const output of outputs) {
  if (/correctLetter|correctText|explanation/.test(output.module)) {
    throw new Error(`Private answer data detected in ${output.file}`);
  }
  writeFileSync(resolve(process.cwd(), output.file), output.module, "utf8");
  console.log(`Sanitized ${output.file}`);
}
