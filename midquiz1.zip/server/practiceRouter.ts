import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  calculatePracticeScore,
  createRandomPracticeSet,
  getPracticeAnswerFeedback,
  getReviewAnswer,
  resolveClientQuestionKey,
  toClientPracticeQuestion,
  type PracticeSource,
} from "./practiceBank";
import {
  createPracticeSession,
  finalizeGradeEstimateSession,
  finalizePracticeSession,
  getLeaderboardEntries,
  getPracticeSession,
  getDb,
  recordPracticeAnswer,
} from "./db";
import { publicProcedure, router } from "./_core/trpc";

const nameSchema = z
  .string()
  .trim()
  .min(1, "اكتب اسمًا مستعارًا للظهور في لوحة المتصدرين.")
  .max(32, "الحد الأقصى للاسم ٣٢ حرفًا.")
  .regex(/^[\p{L}\p{N}][\p{L}\p{N} ._'-]*$/u, "استخدم حروفًا أو أرقامًا ومسافات فقط.");

const SESSION_TTL_MS = 2 * 60 * 60 * 1000;
const GRADE_ESTIMATE_DURATION_MS = 60 * 60 * 1000;

function cleanDisplayName(name: string): string {
  return name.normalize("NFKC").trim().replace(/\s+/g, " ");
}

function normalizeName(name: string): string {
  return cleanDisplayName(name).toLocaleLowerCase("en-US");
}

function databaseUnavailable(): never {
  throw new TRPCError({
    code: "SERVICE_UNAVAILABLE",
    message: "ميزة الاختبار ولوحة المتصدرين غير متاحة مؤقتًا. حاول لاحقًا.",
  });
}

function lockedAnswerError(error: unknown, sessionName: string): never {
  if (error instanceof Error && error.message.includes("already been submitted")) {
    throw new TRPCError({ code: "CONFLICT", message: `تم إنهاء ${sessionName} مسبقًا.` });
  }
  throw error;
}

const answerInput = z.object({
  sessionId: z.string().uuid(),
  questionKey: z.string().regex(/^q(?:0|[1-9]\d*)$/).max(5),
  optionIndex: z.number().int().min(0).max(10),
});

const finishInput = z.object({ sessionId: z.string().uuid() });

export const practiceRouter = router({
  start: publicProcedure
    .input(z.object({ displayName: nameSchema }))
    .mutation(async ({ input }) => {
      if (!(await getDb())) databaseUnavailable();

      const displayName = cleanDisplayName(input.displayName);
      const normalizedName = normalizeName(displayName);
      const questions = createRandomPracticeSet();
      const sessionId = randomUUID();
      const startedAt = new Date();

      await createPracticeSession({
        sessionId,
        normalizedName,
        displayName,
        sessionKind: "leaderboard",
        questionKeys: questions.map(question => question.key),
        startedAt,
      });

      return {
        sessionId,
        startedAt: startedAt.toISOString(),
        questionCount: questions.length,
        questions: questions.map((question, index) => toClientPracticeQuestion(question, index)),
      };
    }),

  startEstimate: publicProcedure.mutation(async () => {
    if (!(await getDb())) databaseUnavailable();

    const questions = createRandomPracticeSet();
    const sessionId = randomUUID();
    const startedAt = new Date();
    await createPracticeSession({
      sessionId,
      normalizedName: `grade-estimate-${sessionId}`,
      displayName: "تقدير تقريبي",
      sessionKind: "grade_estimate",
      questionKeys: questions.map(question => question.key),
      startedAt,
    });

    return {
      sessionId,
      startedAt: startedAt.toISOString(),
      questionCount: questions.length,
      questions: questions.map((question, index) => toClientPracticeQuestion(question, index)),
    };
  }),

  answer: publicProcedure
    .input(answerInput)
    .mutation(async ({ input }) => {
      if (!(await getDb())) databaseUnavailable();

      const session = await getPracticeSession(input.sessionId);
      if (!session) {
        throw new TRPCError({ code: "NOT_FOUND", message: "جلسة الاختبار غير موجودة." });
      }
      if (session.sessionKind !== "leaderboard") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "استخدم مسار محاكاة الدرجة لهذه الجلسة." });
      }
      if (session.completedAt) {
        throw new TRPCError({ code: "CONFLICT", message: "تم إنهاء هذه المحاولة مسبقًا." });
      }
      if (Date.now() - session.startedAt.getTime() > SESSION_TTL_MS) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "انتهى وقت الجلسة؛ ابدأ محاولة جديدة." });
      }
      const questionKey = resolveClientQuestionKey(session.questionKeys, input.questionKey);
      if (!questionKey) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "هذا السؤال لا ينتمي إلى المحاولة الحالية." });
      }
      if (!getPracticeAnswerFeedback(questionKey, input.optionIndex)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "خيار الإجابة غير صالح." });
      }

      try {
        const lockedOptionIndex = await recordPracticeAnswer(
          input.sessionId,
          questionKey,
          input.optionIndex,
        );
        const feedback = getPracticeAnswerFeedback(questionKey, lockedOptionIndex);
        if (!feedback) throw new Error("The locked practice answer is invalid.");
        return { ...feedback, optionIndex: lockedOptionIndex };
      } catch (error) {
        return lockedAnswerError(error, "هذه المحاولة");
      }
    }),

  answerEstimate: publicProcedure
    .input(answerInput)
    .mutation(async ({ input }) => {
      if (!(await getDb())) databaseUnavailable();

      const session = await getPracticeSession(input.sessionId);
      if (!session || session.sessionKind !== "grade_estimate") {
        throw new TRPCError({ code: "NOT_FOUND", message: "جلسة التقدير غير موجودة." });
      }
      if (session.completedAt) {
        throw new TRPCError({ code: "CONFLICT", message: "تم إنهاء هذه المحاكاة مسبقًا." });
      }
      if (Date.now() - session.startedAt.getTime() >= GRADE_ESTIMATE_DURATION_MS) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "انتهى وقت المحاكاة." });
      }
      const questionKey = resolveClientQuestionKey(session.questionKeys, input.questionKey);
      if (!questionKey) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "هذا السؤال لا ينتمي إلى المحاكاة الحالية." });
      }
      if (!getPracticeAnswerFeedback(questionKey, input.optionIndex)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "خيار الإجابة غير صالح." });
      }

      try {
        const optionIndex = await recordPracticeAnswer(
          input.sessionId,
          questionKey,
          input.optionIndex,
        );
        // Deliberately return only the locked selection; correctness is withheld during estimation.
        return { optionIndex };
      } catch (error) {
        return lockedAnswerError(error, "هذه المحاكاة");
      }
    }),

  finish: publicProcedure
    .input(finishInput)
    .mutation(async ({ input }) => {
      if (!(await getDb())) databaseUnavailable();

      const session = await getPracticeSession(input.sessionId);
      if (!session) {
        throw new TRPCError({ code: "NOT_FOUND", message: "جلسة الاختبار غير موجودة." });
      }
      if (session.sessionKind !== "leaderboard") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "هذه جلسة تقدير وليست محاولة ترتيب." });
      }
      if (session.completedAt) {
        throw new TRPCError({ code: "CONFLICT", message: "تم إرسال نتيجة هذه المحاولة مسبقًا." });
      }
      if (Date.now() - session.startedAt.getTime() > SESSION_TTL_MS) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "انتهى وقت الجلسة؛ ابدأ محاولة جديدة." });
      }

      let score: number;
      try {
        const storedAnswers = session.answers ?? {};
        const answerSelections = session.questionKeys.map(key => ({
          key,
          optionIndex: storedAnswers[key] ?? -1,
        }));
        score = calculatePracticeScore(session.questionKeys, answerSelections);
      } catch {
        throw new TRPCError({ code: "BAD_REQUEST", message: "تعذّر التحقق من إجابات الاختبار." });
      }

      try {
        return await finalizePracticeSession(input.sessionId, score, new Date());
      } catch (error) {
        return lockedAnswerError(error, "هذه المحاولة");
      }
    }),

  finishEstimate: publicProcedure
    .input(finishInput)
    .mutation(async ({ input }) => {
      if (!(await getDb())) databaseUnavailable();

      const session = await getPracticeSession(input.sessionId);
      if (!session || session.sessionKind !== "grade_estimate") {
        throw new TRPCError({ code: "NOT_FOUND", message: "جلسة التقدير غير موجودة." });
      }
      if (session.completedAt) {
        throw new TRPCError({ code: "CONFLICT", message: "تم إرسال نتيجة هذه المحاكاة مسبقًا." });
      }

      const timedOut = Date.now() - session.startedAt.getTime() >= GRADE_ESTIMATE_DURATION_MS;
      const storedAnswers = session.answers ?? {};
      if (!timedOut && session.questionKeys.some(key => storedAnswers[key] === undefined)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "أجب عن جميع الأسئلة قبل إنهاء المحاكاة." });
      }

      let score: number;
      try {
        const answerSelections = session.questionKeys.map(key => ({
          key,
          optionIndex: storedAnswers[key] ?? -1,
        }));
        score = calculatePracticeScore(
          session.questionKeys,
          answerSelections,
          { allowUnanswered: timedOut },
        );
      } catch {
        throw new TRPCError({ code: "BAD_REQUEST", message: "تعذّر التحقق من إجابات المحاكاة." });
      }

      try {
        return await finalizeGradeEstimateSession(input.sessionId, score, new Date());
      } catch (error) {
        return lockedAnswerError(error, "هذه المحاكاة");
      }
    }),

  revealAnswer: publicProcedure
    .input(
      z.object({
        source: z.enum(["quiz1", "quiz2", "assignment1"]),
        questionId: z.number().int().min(1).max(20),
      }),
    )
    .mutation(({ input }) => {
      const answer = getReviewAnswer(input.source as PracticeSource, input.questionId);
      if (!answer) {
        throw new TRPCError({ code: "NOT_FOUND", message: "لم يتم العثور على إجابة هذا السؤال." });
      }
      return answer;
    }),

  leaderboard: publicProcedure.query(async () => {
    if (!(await getDb())) databaseUnavailable();
    return getLeaderboardEntries(20);
  }),
});
