import {
  quiz1Questions,
  type Option,
  type Question,
} from "./data/quiz1";
import { quiz2Questions } from "./data/quiz2";
import { assignment1Questions } from "./data/assignment1";

export type PracticeSource = "quiz1" | "quiz2" | "assignment1";

type SourceQuestion = Question & {
  essay?: boolean;
  correctLetter: string;
  correctText: string;
  explanation: string;
};

export type PracticeQuestion = {
  key: string;
  source: PracticeSource;
  sourceTitle: string;
  id: number;
  prompt: string;
  options: Option[];
  correctIndex: number;
};

export type ClientPracticeQuestion = {
  key: string;
  sourceTitle: string;
  prompt: string;
  options: Option[];
};

const sourceDefinitions: {
  source: PracticeSource;
  sourceTitle: string;
  questions: SourceQuestion[];
  count: number;
}[] = [
  { source: "quiz1", sourceTitle: "Quiz 1", questions: quiz1Questions, count: 7 },
  { source: "quiz2", sourceTitle: "Quiz 2", questions: quiz2Questions, count: 7 },
  {
    source: "assignment1",
    sourceTitle: "Assignment 1",
    questions: assignment1Questions,
    count: 6,
  },
];

function getCorrectIndex(question: SourceQuestion): number {
  if (question.correctLetter) {
    return question.options.findIndex(option => option.letter === question.correctLetter);
  }
  return question.options.findIndex(option => option.text === question.correctText);
}

const questionBank: PracticeQuestion[] = sourceDefinitions.flatMap(group =>
  group.questions
    .filter(question => !question.essay && question.options.length > 0)
    .map(question => {
      const correctIndex = getCorrectIndex(question);
      if (correctIndex < 0) {
        throw new Error(`No matching answer option for ${group.source}:${question.id}`);
      }
      return {
        key: `${group.source}:${question.id}`,
        source: group.source,
        sourceTitle: group.sourceTitle,
        id: question.id,
        prompt: question.prompt,
        options: question.options,
        correctIndex,
      };
    }),
);

const bankByKey = new Map(questionBank.map(question => [question.key, question]));

function shuffle<T>(items: T[], random: () => number): T[] {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index--) {
    const swapWith = Math.floor(random() * (index + 1));
    [result[index], result[swapWith]] = [result[swapWith], result[index]];
  }
  return result;
}

export function createRandomPracticeSet(random: () => number = Math.random): PracticeQuestion[] {
  const selected: PracticeQuestion[] = [];
  for (const group of sourceDefinitions) {
    const available = questionBank.filter(question => question.source === group.source);
    if (available.length < group.count) {
      throw new Error(`Not enough auto-gradable questions in ${group.source}`);
    }
    selected.push(...shuffle(available, random).slice(0, group.count));
  }
  return shuffle(selected, random);
}

export function toClientPracticeQuestion(question: PracticeQuestion, index: number): ClientPracticeQuestion {
  return {
    key: `q${index}`,
    sourceTitle: question.sourceTitle,
    prompt: question.prompt,
    options: question.options,
  };
}

export function resolveClientQuestionKey(questionKeys: string[], clientKey: string): string | undefined {
  const match = /^q(0|[1-9]\d*)$/.exec(clientKey);
  if (!match) return undefined;
  return questionKeys[Number(match[1])];
}

export function getReviewAnswer(
  source: PracticeSource,
  questionId: number,
): { correctLetter: string; correctText: string; explanation: string } | undefined {
  const group = sourceDefinitions.find(definition => definition.source === source);
  const question = group?.questions.find(item => item.id === questionId);
  if (!question) return undefined;
  return {
    correctLetter: question.correctLetter,
    correctText: question.correctText,
    explanation: question.explanation,
  };
}

export type PracticeAnswerFeedback =
  | { isCorrect: true }
  | { isCorrect: false; correctLetter: string; correctText: string; explanation: string };

export function getPracticeAnswerFeedback(
  key: string,
  selectedIndex: number,
): PracticeAnswerFeedback | undefined {
  const question = bankByKey.get(key);
  if (
    !question ||
    !Number.isInteger(selectedIndex) ||
    selectedIndex < 0 ||
    selectedIndex >= question.options.length
  ) {
    return undefined;
  }
  if (selectedIndex === question.correctIndex) return { isCorrect: true };

  const sourceQuestion = sourceDefinitions
    .find(group => group.source === question.source)
    ?.questions.find(item => item.id === question.id);
  if (!sourceQuestion) return undefined;

  return {
    isCorrect: false,
    correctLetter: sourceQuestion.correctLetter,
    correctText: sourceQuestion.correctText,
    explanation: sourceQuestion.explanation,
  };
}

export function calculatePracticeScore(
  expectedKeys: string[],
  answers: { key: string; optionIndex: number }[],
  options: { allowUnanswered?: boolean } = {},
): number {
  if (expectedKeys.length !== 20 || answers.length !== expectedKeys.length) {
    throw new Error("The completed test must contain 20 answers.");
  }
  const expected = new Set(expectedKeys);
  const answersByKey = new Map(answers.map(answer => [answer.key, answer.optionIndex]));
  if (
    expected.size !== expectedKeys.length ||
    answersByKey.size !== answers.length ||
    answers.some(answer => !expected.has(answer.key))
  ) {
    throw new Error("Answers do not match the issued test.");
  }

  let score = 0;
  for (const key of expectedKeys) {
    const question = bankByKey.get(key);
    const selected = answersByKey.get(key);
    if (
      !question ||
      selected === undefined ||
      !Number.isInteger(selected) ||
      (selected < 0 && !(options.allowUnanswered && selected === -1)) ||
      selected >= question.options.length
    ) {
      throw new Error("An answer selection is invalid.");
    }
    if (selected === -1) continue;
    if (selected === question.correctIndex) score++;
  }
  return score;
}
