import { asc, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  PracticeSession,
  leaderboardEntries,
  practiceSessions,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

function requireDatabase(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new Error("Database is not available");
  return db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = requireDatabase(await getDb());
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createPracticeSession(input: {
  sessionId: string;
  normalizedName: string;
  displayName: string;
  sessionKind: "leaderboard" | "grade_estimate";
  questionKeys: string[];
  startedAt: Date;
}): Promise<void> {
  const db = requireDatabase(await getDb());
  await db.insert(practiceSessions).values(input);
}

export async function getPracticeSession(sessionId: string): Promise<PracticeSession | undefined> {
  const db = requireDatabase(await getDb());
  const [session] = await db
    .select()
    .from(practiceSessions)
    .where(eq(practiceSessions.sessionId, sessionId))
    .limit(1);
  return session;
}

export async function recordPracticeAnswer(
  sessionId: string,
  questionKey: string,
  optionIndex: number,
): Promise<number> {
  const db = requireDatabase(await getDb());

  return db.transaction(async tx => {
    const [session] = await tx
      .select()
      .from(practiceSessions)
      .where(eq(practiceSessions.sessionId, sessionId))
      .for("update")
      .limit(1);

    if (!session) throw new Error("Practice session was not found.");
    if (session.completedAt) throw new Error("This practice session has already been submitted.");
    if (!session.questionKeys.includes(questionKey)) throw new Error("Question is not part of this session.");

    const answers = session.answers ?? {};
    if (Object.prototype.hasOwnProperty.call(answers, questionKey)) {
      return answers[questionKey];
    }

    const updatedAnswers = { ...answers, [questionKey]: optionIndex };
    await tx
      .update(practiceSessions)
      .set({ answers: updatedAnswers })
      .where(eq(practiceSessions.sessionId, sessionId));
    return optionIndex;
  });
}

export async function finalizePracticeSession(
  sessionId: string,
  score: number,
  completedAt: Date,
): Promise<{ displayName: string; score: number; elapsedSeconds: number }> {
  const db = requireDatabase(await getDb());

  return db.transaction(async tx => {
    const [session] = await tx
      .select()
      .from(practiceSessions)
      .where(eq(practiceSessions.sessionId, sessionId))
      .for("update")
      .limit(1);

    if (!session) throw new Error("Practice session was not found.");
    if (session.completedAt) throw new Error("This practice session has already been submitted.");
    if (session.sessionKind !== "leaderboard") throw new Error("This session cannot be ranked.");

    const elapsedSeconds = Math.max(
      1,
      Math.floor((completedAt.getTime() - session.startedAt.getTime()) / 1000),
    );

    await tx
      .update(practiceSessions)
      .set({ score, elapsedSeconds, completedAt })
      .where(eq(practiceSessions.sessionId, sessionId));

    await tx
      .insert(leaderboardEntries)
      .values({
        normalizedName: session.normalizedName,
        displayName: session.displayName,
        bestScore: score,
        bestElapsedSeconds: elapsedSeconds,
        attemptCount: 1,
        createdAt: completedAt,
        updatedAt: completedAt,
      })
      .onDuplicateKeyUpdate({
        set: {
          displayName: session.displayName,
          bestElapsedSeconds: sql`CASE
            WHEN ${score} > ${leaderboardEntries.bestScore}
              OR (${score} = ${leaderboardEntries.bestScore} AND ${elapsedSeconds} < ${leaderboardEntries.bestElapsedSeconds})
            THEN ${elapsedSeconds}
            ELSE ${leaderboardEntries.bestElapsedSeconds}
          END`,
          bestScore: sql`GREATEST(${leaderboardEntries.bestScore}, ${score})`,
          attemptCount: sql`${leaderboardEntries.attemptCount} + 1`,
          updatedAt: completedAt,
        },
      });

    return { displayName: session.displayName, score, elapsedSeconds };
  });
}

export async function finalizeGradeEstimateSession(
  sessionId: string,
  score: number,
  completedAt: Date,
): Promise<{ score: number; elapsedSeconds: number; questionCount: number }> {
  const db = requireDatabase(await getDb());

  return db.transaction(async tx => {
    const [session] = await tx
      .select()
      .from(practiceSessions)
      .where(eq(practiceSessions.sessionId, sessionId))
      .for("update")
      .limit(1);

    if (!session) throw new Error("Practice session was not found.");
    if (session.sessionKind !== "grade_estimate") throw new Error("This is not a grade-estimate session.");
    if (session.completedAt) throw new Error("This practice session has already been submitted.");

    const elapsedSeconds = Math.min(
      60 * 60,
      Math.max(1, Math.floor((completedAt.getTime() - session.startedAt.getTime()) / 1000)),
    );

    await tx
      .update(practiceSessions)
      .set({ score, elapsedSeconds, completedAt })
      .where(eq(practiceSessions.sessionId, sessionId));

    return { score, elapsedSeconds, questionCount: session.questionKeys.length };
  });
}

export async function getLeaderboardEntries(limit = 20) {
  const db = requireDatabase(await getDb());
  return db
    .select({
      displayName: leaderboardEntries.displayName,
      bestScore: leaderboardEntries.bestScore,
      bestElapsedSeconds: leaderboardEntries.bestElapsedSeconds,
      attemptCount: leaderboardEntries.attemptCount,
    })
    .from(leaderboardEntries)
    .orderBy(
      desc(leaderboardEntries.bestScore),
      asc(leaderboardEntries.bestElapsedSeconds),
      asc(leaderboardEntries.displayName),
    )
    .limit(limit);
}
