import { describe, expect, it } from "vitest";
import {
  calculatePracticeScore,
  createRandomPracticeSet,
  getPracticeAnswerFeedback,
  getReviewAnswer,
  resolveClientQuestionKey,
  toClientPracticeQuestion,
} from "./practiceBank";

describe("random practice set", () => {
  it("selects 20 unique auto-gradable questions in the approved 7/7/6 mix", () => {
    const questions = createRandomPracticeSet(() => 0.37);
    expect(questions).toHaveLength(20);
    expect(new Set(questions.map(question => question.key)).size).toBe(20);
    expect(questions.filter(question => question.source === "quiz1")).toHaveLength(7);
    expect(questions.filter(question => question.source === "quiz2")).toHaveLength(7);
    expect(questions.filter(question => question.source === "assignment1")).toHaveLength(6);
    expect(questions.every(question => question.options.length > 0)).toBe(true);
    expect(questions.some(question => question.key === "assignment1:1" || question.key === "assignment1:20")).toBe(false);
  });

  it("scores only the issued answer keys and rejects invalid question sets", () => {
    const questions = createRandomPracticeSet(() => 0.61);
    const perfectAnswers = questions.map(question => ({
      key: question.key,
      optionIndex: question.correctIndex,
    }));
    expect(calculatePracticeScore(questions.map(question => question.key), perfectAnswers)).toBe(20);

    const oneWrong = perfectAnswers.map((answer, index) =>
      index === 0
        ? { ...answer, optionIndex: (answer.optionIndex + 1) % questions[0].options.length }
        : answer,
    );
    expect(calculatePracticeScore(questions.map(question => question.key), oneWrong)).toBe(19);
    expect(() => calculatePracticeScore(questions.map(question => question.key), perfectAnswers.slice(1))).toThrow();
  });

  it("counts unanswered questions as wrong only when the estimate timer expires", () => {
    const questions = createRandomPracticeSet(() => 0.41);
    const answers = questions.map((question, index) => ({
      key: question.key,
      optionIndex: index < 2 ? -1 : question.correctIndex,
    }));
    const keys = questions.map(question => question.key);

    expect(calculatePracticeScore(keys, answers, { allowUnanswered: true })).toBe(18);
    expect(() => calculatePracticeScore(keys, answers)).toThrow();
  });

  it("does not send correct-answer indexes to the browser", () => {
    const [question] = createRandomPracticeSet(() => 0.23);
    const publicQuestion = toClientPracticeQuestion(question, 0);
    expect(publicQuestion).not.toHaveProperty("correctIndex");
    expect(publicQuestion).not.toHaveProperty("correctLetter");
    expect(publicQuestion).not.toHaveProperty("source");
    expect(publicQuestion).not.toHaveProperty("id");
    expect(publicQuestion.key).toBe("q0");
  });

  it("resolves opaque question indexes only within the issued test", () => {
    const keys = ["quiz1:1", "quiz2:5"];
    expect(resolveClientQuestionKey(keys, "q0")).toBe("quiz1:1");
    expect(resolveClientQuestionKey(keys, "q1")).toBe("quiz2:5");
    expect(resolveClientQuestionKey(keys, "q2")).toBeUndefined();
    expect(resolveClientQuestionKey(keys, "quiz1:1")).toBeUndefined();
  });

  it("returns a single answer only when the review action requests it", () => {
    expect(getReviewAnswer("quiz1", 1)).toMatchObject({
      correctLetter: "B",
      correctText: "False",
    });
    expect(getReviewAnswer("quiz1", 99)).toBeUndefined();
  });

  it("confirms correct picks and explains a wrong pick with the right option", () => {
    const question = createRandomPracticeSet(() => 0.29)[0];
    const wrongIndex = (question.correctIndex + 1) % question.options.length;

    expect(getPracticeAnswerFeedback(question.key, question.correctIndex)).toEqual({ isCorrect: true });
    expect(getPracticeAnswerFeedback(question.key, wrongIndex)).toMatchObject({
      isCorrect: false,
      correctText: question.options[question.correctIndex].text,
      explanation: expect.any(String),
    });
    expect(getPracticeAnswerFeedback(question.key, question.options.length)).toBeUndefined();
  });
});
