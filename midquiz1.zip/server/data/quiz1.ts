export type Option = {
  letter: string;
  text: string;
};

export type Question = {
  id: number;
  prompt: string;
  options: Option[];
  correctLetter: string;
  correctText: string;
  explanation: string;
};

export const quiz1Questions: Question[] = [
  {
    id: 1,
    prompt: "If 3+5=8, then 2*4=9. What is the truth value of this conditional statement?",
    options: [
      { letter: "A", text: "True" },
      { letter: "B", text: "False" },
    ],
    correctLetter: "B",
    correctText: "False",
    explanation:
      "الشرط الأول صحيح والنتيجة الثانية خاطئة؛ والشرطية تكون خاطئة فقط عندما يكون المقدّم صحيحًا والتالي خاطئًا.",
  },
  {
    id: 2,
    prompt:
      'Translate the following statement into logical expression: "You can take the course only if you have passed prerequisite 1 and prerequisite 2." Let p: You have passed prerequisite 1, q: You can take the course, and r: You have passed prerequisite 2.',
    options: [
      { letter: "A", text: "q → (p ∧ r)" },
      { letter: "B", text: "(p ∧ r) → q" },
      { letter: "C", text: "q → (p ∨ r)" },
      { letter: "D", text: "(p ∨ r) → q" },
    ],
    correctLetter: "A",
    correctText: "q → (p ∧ r)",
    explanation:
      "عبارة «فقط إذا» تجعل الشرط اللازم في الطرف الأيمن: إذا أمكنك أخذ المقرر، فقد اجتزت المتطلبين معًا.",
  },
  {
    id: 3,
    prompt:
      'What is the truth value of the biconditional statement "7+2 = 9 if and only if 5 > 10"?',
    options: [
      { letter: "A", text: "True" },
      { letter: "B", text: "False" },
    ],
    correctLetter: "B",
    correctText: "False",
    explanation:
      "العبارة الأولى صحيحة والثانية خاطئة؛ والتكافؤ المادي يكون صحيحًا عندما تتساوى قيمتا العبارتين.",
  },
  {
    id: 4,
    prompt: "Are (p ∧ q) → r and (p → r) ∨ (q → r) logically equivalent?",
    options: [
      { letter: "A", text: "True" },
      { letter: "B", text: "False" },
    ],
    correctLetter: "A",
    correctText: "True",
    explanation:
      "كلا الطرفين يكافئ ¬p ∨ ¬q ∨ r؛ لذا فلهما قيمة الصدق نفسها في جميع الحالات.",
  },
  {
    id: 5,
    prompt:
      'Use De Morgan\'s laws to find the negation of the statement "The weather in Makkah is hot and sunny."',
    options: [
      { letter: "A", text: "The weather in Makkah is not hot or not sunny" },
      { letter: "B", text: "The weather in Makkah is not hot and not sunny" },
      {
        letter: "C",
        text: "If the weather in Makkah is not hot, then it is not sunny",
      },
      { letter: "D", text: "The weather in Makkah is hot or sunny" },
    ],
    correctLetter: "A",
    correctText: "The weather in Makkah is not hot or not sunny",
    explanation:
      "وفق قانون دي مورغان، نفي اقتران عبارتين يساوي نفي الأولى أو نفي الثانية.",
  },
  {
    id: 6,
    prompt:
      'What is the truth value of the biconditional statement "10/2 = 5 if and only if 3 * 4 = 12"?',
    options: [
      { letter: "A", text: "True" },
      { letter: "B", text: "False" },
    ],
    correctLetter: "A",
    correctText: "True",
    explanation:
      "كلتا العبارتين صحيحتان؛ لذلك فالتكافؤ بينهما صحيح.",
  },
  {
    id: 7,
    prompt: "When is a biconditional statement p ↔ q TRUE?",
    options: [
      { letter: "A", text: "When p is true and q is false" },
      { letter: "B", text: "p and q have the same truth values" },
      { letter: "C", text: "When p is false and q is true" },
      { letter: "D", text: "When p and q have different truth values" },
    ],
    correctLetter: "B",
    correctText: "p and q have the same truth values",
    explanation:
      "يكون p ↔ q صحيحًا إذا كانت p وq كلتاهما صحيحتين أو كلتاهما خاطئتين.",
  },
  {
    id: 8,
    prompt:
      'Use De Morgan\'s laws to find the negation of the statement: "Ahmed is good and hard working."',
    options: [
      { letter: "A", text: "Ahmed is not good or not hard working" },
      { letter: "B", text: "Ahmed is not good and not hard working" },
      {
        letter: "C",
        text: "If Ahmed is not good, then he is not hard working",
      },
      { letter: "D", text: "Ahmed is good or hard working" },
    ],
    correctLetter: "A",
    correctText: "Ahmed is not good or not hard working",
    explanation:
      "نفي «جيد ومجتهد» هو «ليس جيدًا أو ليس مجتهدًا»؛ ويتحول الاقتران إلى فصل عند النفي.",
  },
  {
    id: 9,
    prompt:
      "Are these system specifications consistent? Given the list of propositions: p → q, p ∨ q, ¬p",
    options: [
      { letter: "A", text: "Yes, Consistent" },
      { letter: "B", text: "Not Consistent" },
    ],
    correctLetter: "A",
    correctText: "Yes, Consistent",
    explanation:
      "يمكن اختيار p = False وq = True؛ عندها تصح p → q وp ∨ q و¬p معًا.",
  },
  {
    id: 10,
    prompt: "When is the conditional statement p → q false?",
    options: [
      { letter: "A", text: "When p is false, and q is true" },
      { letter: "B", text: "When both p and q are false" },
      { letter: "C", text: "When both p and q are true" },
      { letter: "D", text: "When p is true, and q is false" },
    ],
    correctLetter: "D",
    correctText: "When p is true, and q is false",
    explanation:
      "الشرطية p → q خاطئة في حالة واحدة فقط: p صحيحة وq خاطئة.",
  },
  {
    id: 11,
    prompt:
      "Are these system specifications consistent? Given the list of propositions: p ↔ q, p ∨ q, ¬p",
    options: [
      { letter: "A", text: "Yes, Consistent" },
      { letter: "B", text: "Not Consistent" },
    ],
    correctLetter: "B",
    correctText: "Not Consistent",
    explanation:
      "من ¬p نعرف أن p خاطئة، ومن p ∨ q يلزم أن q صحيحة؛ عندها p ↔ q خاطئة، فلا تتحقق المواصفات كلها معًا.",
  },
  {
    id: 12,
    prompt:
      'Translate the following English sentence to the logical expression: "You can not drive the car if you are under 18 years old unless you have supervision from your parent" and let p: You can drive the car, q: You are under 18 years old, and s: You have supervision from your parent',
    options: [
      { letter: "A", text: "¬p → (q ∧ ¬s)" },
      { letter: "B", text: "(q ∧ ¬s) → ¬p" },
      { letter: "C", text: "p → (q ∧ s)" },
      { letter: "D", text: "(q ∧ s) → p" },
    ],
    correctLetter: "B",
    correctText: "(q ∧ ¬s) → ¬p",
    explanation:
      "المقصود: إذا كان العمر دون 18 ولا توجد مرافقة من الوالد، فلا يمكنك قيادة السيارة.",
  },
  {
    id: 13,
    prompt: "Which of the following sentences is considered a proposition?",
    options: [
      { letter: "A", text: "Sit down" },
      { letter: "B", text: "x + 1 = 1" },
      { letter: "C", text: "1 + 0 = 2" },
      { letter: "D", text: "What time is it?" },
    ],
    correctLetter: "C",
    correctText: "1 + 0 = 2",
    explanation:
      "القضية جملة خبرية لها قيمة صدق محددة. وهذه الجملة خبرية (وقيمتها خاطئة)، بخلاف الأمر والسؤال والجملة المفتوحة ذات المتغير.",
  },
  {
    id: 14,
    prompt:
      "Smartphone Specifications Reference:\n• Smartphone A: 256 MB RAM, 32 GB ROM, 8 MP Camera\n• Smartphone B: 288 MB RAM, 64 GB ROM, 4 MP Camera\n\nWhat is the logical truth value of the biconditional statement: \"Smartphone A has more RAM than Smartphone B if and only if Smartphone B has more RAM than Smartphone A\"?",
    options: [
      { letter: "A", text: "True" },
      { letter: "B", text: "False" },
    ],
    correctLetter: "B",
    correctText: "False",
    explanation:
      "العبارة «A لديها RAM أكثر» خاطئة (256 أقل من 288)، بينما «B لديها RAM أكثر» صحيحة؛ والقيمتان مختلفتان.",
  },
  {
    id: 15,
    prompt:
      "what is truth value for the following argument:\nThe weither in Makkah is hot and sunny\nsuppose that both staments are true",
    options: [
      { letter: "A", text: "True" },
      { letter: "B", text: "False" },
    ],
    correctLetter: "A",
    correctText: "True",
    explanation:
      "بما أن السؤال يفترض أن العبارتين «حار» و«مشمس» صحيحتان، فاقترانهما صحيح.",
  },
  {
    id: 16,
    prompt: "Which of the following conditional statements is FALSE?",
    options: [
      {
        letter: "A",
        text: "If Makkah is in Saudi Arabia, then 2+2 = 4",
      },
      { letter: "B", text: "If apples are fruits, then 3+3 = 7" },
      { letter: "C", text: "If 2+2 = 5, then the sky is green" },
      { letter: "D", text: "if 1 = 0, then 2 = 2" },
    ],
    correctLetter: "B",
    correctText: "If apples are fruits, then 3+3 = 7",
    explanation:
      "في الخيار B المقدّم صحيح (التفاح من الفواكه) والنتيجة خاطئة (3+3 لا يساوي 7)، فتكون الشرطية خاطئة.",
  },
  {
    id: 17,
    prompt:
      'Use De Morgan\'s laws to find the negation of the following statement:\n"The laptop is lightweight and powerful."',
    options: [
      {
        letter: "A",
        text: "The laptop is not lightweight and it is not powerful",
      },
      { letter: "B", text: "The laptop is lightweight or powerful" },
      {
        letter: "C",
        text: "If the laptop is not lightweight, then it is not powerful",
      },
      {
        letter: "D",
        text: "The laptop is not lightweight or it is not powerful",
      },
    ],
    correctLetter: "D",
    correctText: "The laptop is not lightweight or it is not powerful",
    explanation:
      "ينفي قانون دي مورغان اقتران «خفيف وقوي» إلى «ليس خفيفًا أو ليس قويًا».",
  },
  {
    id: 18,
    prompt:
      "Many mathematical statements are constructed by combining one or more propositions. What are these called?",
    options: [
      { letter: "A", text: "Logical Connectives" },
      { letter: "B", text: "Propositional Variables" },
      { letter: "C", text: "Propositional Calculus" },
      { letter: "D", text: "Compound Propositions" },
    ],
    correctLetter: "D",
    correctText: "Compound Propositions",
    explanation:
      "العبارات الناتجة عن ربط قضية واحدة أو أكثر تُسمى قضايا مركبة.",
  },
  {
    id: 19,
    prompt:
      "Let p and q be the propositions\np: It is below freezing\nq: It is snowing\nwhat is the logical expression for the following statment\nit is snowing if it is below freezing\nChoose the correct answer between all choices",
    options: [
      { letter: "A", text: "p ∧ q" },
      { letter: "B", text: "p ∨ q" },
      { letter: "C", text: "¬p ∧ ¬q" },
      { letter: "D", text: "p → q" },
    ],
    correctLetter: "D",
    correctText: "p → q",
    explanation:
      "«إن كانت الحرارة دون التجمد، فالثلج يتساقط» تعني: إذا كانت p فـ q، أي p → q.",
  },
  {
    id: 20,
    prompt:
      "Smartphone Specifications Reference:\n• Smartphone A: 256 MB RAM, 64 GB ROM, 5 MP Camera\n• Smartphone B: 128 MB RAM, 32 GB ROM, 8 MP Camera\n\nConsider the conditional statement: \"If Smartphone A has more RAM and more ROM than Smartphone B, then it also has a higher-resolution camera.\" What is the truth value of this statement?",
    options: [
      { letter: "A", text: "True" },
      { letter: "B", text: "False" },
    ],
    correctLetter: "B",
    correctText: "False",
    explanation:
      "المقدّم صحيح: A لديها RAM وROM أكثر. لكن النتيجة خاطئة لأن 5 MP أقل من 8 MP؛ لذلك فالشرطية خاطئة.",
  },
];
