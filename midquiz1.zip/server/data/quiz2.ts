import type { Question } from "./quiz1";

export const quiz2Questions: Question[] = [
  {
    id: 1,
    prompt:
      "What is the truth value of the nested quantification ∀ x ∃ y (x² = y) if the domain consists of all real numbers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "True",
    explanation:
      "لكل عدد حقيقي x يمكن اختيار y = x²، ومربع العدد الحقيقي عدد حقيقي؛ لذا العبارة صحيحة.",
  },
  {
    id: 2,
    prompt:
      "Let Q(x, y, z) be the statement x + y = z. What is the truth value of ∀ x ∀ y ∃ z Q(x, y, z), where the domain consists of all real numbers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "True",
    explanation:
      "لكل x وy حقيقيين، يمكن اختيار z = x + y، والناتج عدد حقيقي.",
  },
  {
    id: 3,
    prompt:
      "According to De Morgan's Laws for Quantifiers, which logical statement is equivalent to the negation of ∃ x (x² = 2)?",
    options: [
      { letter: "A", text: "∀ x (x² ≠ 2)" },
      { letter: "B", text: "∀ x (x² < 2)" },
      { letter: "C", text: "∀ x (x² = 2)" },
      { letter: "D", text: "∃ x (x² < 2)" },
    ],
    correctLetter: "A",
    correctText: "∀ x (x² ≠ 2)",
    explanation:
      "نفي ∃ يتحول إلى ∀، ونفي المساواة x² = 2 هو x² ≠ 2.",
  },
  {
    id: 4,
    prompt:
      "Let P(x, y) be the statement xy = 1. What is the truth value of ∃ x ∀ y P(x, y) if the domain is all integer numbers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "False",
    explanation:
      "لا يوجد عدد صحيح x يجعل xy = 1 لكل الأعداد الصحيحة y؛ فمثلًا عند y = 0 يكون xy = 0.",
  },
  {
    id: 5,
    prompt:
      "What is the truth value of the existential quantification ∃ x (x = x + 1), where the domain consists of all integer numbers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "False",
    explanation:
      "المعادلة x = x + 1 تعني 0 = 1، وهذا مستحيل لأي عدد صحيح.",
  },
  {
    id: 6,
    prompt:
      "What is the truth value of ∀ x ∃ y (x + y = 0) if the domain is all real numbers?",
    options: [
      {
        letter: "A",
        text: "True, because every real number has an additive inverse.",
      },
      { letter: "B", text: "False, because x and y must be positive." },
      { letter: "C", text: "True, because x and y can both be 1." },
      { letter: "D", text: "False, because zero does not have an inverse." },
    ],
    correctLetter: "A",
    correctText: "True, because every real number has an additive inverse.",
    explanation:
      "لكل عدد حقيقي x، اختر y = −x؛ عندها x + y = 0.",
  },
  {
    id: 7,
    prompt:
      "What is the truth value of the quantification ∀ x (x² > x) if the domain consists of all integers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "False",
    explanation:
      "يكفي مثال مضاد واحد؛ عند x = 1 نحصل على 1² > 1، وهي عبارة خاطئة.",
  },
  {
    id: 8,
    prompt:
      "Let Q(x, y, z) be the statement x + y = z. What is the truth value of ∃ z ∀ x ∀ y Q(x, y, z), where the domain consists of all real numbers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "False",
    explanation:
      "لا يوجد عدد حقيقي ثابت z يساوي مجموع كل زوج من الأعداد الحقيقية x وy.",
  },
  {
    id: 9,
    prompt:
      "What is the truth value of ∀ x P(x), where P(x) is the statement x² < 10 and the domain consists of the positive integers not exceeding 4?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "False",
    explanation:
      "المجال هو {1, 2, 3, 4}؛ وعند x = 4 تكون 16 < 10 خاطئة، فتفشل الكمية الكلية.",
  },
  {
    id: 10,
    prompt:
      "Let P(x) denote the statement x > 3. What is the truth value of the existential quantification ∃ x P(x) if the domain consists of all real numbers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "True",
    explanation:
      "توجد أعداد حقيقية أكبر من 3؛ مثلًا x = 4.",
  },
  {
    id: 11,
    prompt:
      "What is the truth value of the quantification ∀ x (x² > x) if the domain consists of all real numbers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "False",
    explanation:
      "عند x = 1 يكون x² = x، فلا تتحقق المتباينة الصارمة x² > x.",
  },
  {
    id: 12,
    prompt:
      'Translate the statement "The sum of two positive integers is always positive" into a logical expression, where the domain for both variables consists of all integers.',
    options: [
      {
        letter: "A",
        text: "∀ x ∀ y ((x > 0) ∧ (y > 0) → (x + y > 0))",
      },
      {
        letter: "B",
        text: "∃ x ∃ y ((x > 0) ∧ (y > 0) → (x + y > 0))",
      },
      {
        letter: "C",
        text: "∀ x ∀ y ((x > 0) ∨ (y > 0) → (x + y > 0))",
      },
      {
        letter: "D",
        text: "∀ x ∃ y ((x > 0) ∧ (y > 0) → (x + y > 0))",
      },
    ],
    correctLetter: "A",
    correctText: "∀ x ∀ y ((x > 0) ∧ (y > 0) → (x + y > 0))",
    explanation:
      "«دائمًا» تتطلب كمًّا كليًا على x وy، ويجب أن يكون كل منهما موجبًا قبل استنتاج أن مجموعهما موجب.",
  },
  {
    id: 13,
    prompt:
      'Consider the argument: "If George does not have eight legs, then he is not a spider. George is not a spider. Therefore, George has eight legs." Determine whether the argument is valid.',
    options: [
      { letter: "A", text: "Valid" },
      { letter: "B", text: "Invalid" },
    ],
    correctLetter: "B",
    correctText: "Invalid",
    explanation:
      "من صحة النتيجة «ليس عنكبوتًا» لا يلزم أن جورج له ثماني أرجل؛ فهذا استدلال غير صالح.",
  },
  {
    id: 14,
    prompt:
      'Consider the argument: "If it snows, then I will study discrete math. If I study discrete math, I will get an A. Therefore, if it snows, I will get an A." Determine whether the argument is valid.',
    options: [
      { letter: "A", text: "Valid" },
      { letter: "B", text: "Invalid" },
    ],
    correctLetter: "A",
    correctText: "Valid",
    explanation:
      "هذا تطبيق لقاعدة القياس الشرطي: إذا كان الثلج يؤدي إلى دراسة المادة، والدراسة تؤدي إلى A، فالثلج يؤدي إلى A.",
  },
  {
    id: 15,
    prompt:
      "Determine the truth value of ∃ n (n = −n) if the domain consists of all integers.",
    options: [
      { letter: "A", text: "False, because zero is not an integer." },
      { letter: "B", text: "True, because n = 0 satisfies the equation." },
      {
        letter: "C",
        text: "False, because a positive number cannot equal a negative number.",
      },
      { letter: "D", text: "True, because n = 1 satisfies the equation." },
    ],
    correctLetter: "B",
    correctText: "True, because n = 0 satisfies the equation.",
    explanation:
      "الصفر عدد صحيح ويحقق 0 = −0؛ لذا فإن وجود عدد صحيح واحد يحقق العبارة يكفي.",
  },
  {
    id: 16,
    prompt:
      "Determine the truth value of ∀ n (n + 1 > n) if the domain consists of all integers.",
    options: [
      { letter: "A", text: "Invalid" },
      { letter: "B", text: "False" },
      { letter: "C", text: "True" },
      { letter: "D", text: "Contingency" },
    ],
    correctLetter: "C",
    correctText: "True",
    explanation:
      "إضافة 1 إلى أي عدد صحيح تجعله أكبر منه، لذلك تصح العبارة لكل n صحيح.",
  },
  {
    id: 17,
    prompt:
      "Let the domain for all variables consist of all real numbers. Which English sentence translates the logical expression ∀ x ∀ y ((x > 0) ∧ (y < 0) → (xy < 0))?",
    options: [
      {
        letter: "A",
        text: "The product of a positive real number and a negative real number is always a negative real number.",
      },
      {
        letter: "B",
        text: "The sum of a positive real number and a negative real number is always a negative real number.",
      },
      {
        letter: "C",
        text: "The product of two positive real numbers is always a negative real number.",
      },
      {
        letter: "D",
        text: "There exists a positive real number and a negative real number whose product is negative.",
      },
    ],
    correctLetter: "A",
    correctText:
      "The product of a positive real number and a negative real number is always a negative real number.",
    explanation:
      "الصيغة تتحدث عن كل عددين حقيقيين؛ إذا كان الأول موجبًا والثاني سالبًا، فحاصل ضربهما سالب.",
  },
  {
    id: 18,
    prompt:
      'Consider the argument: "I will study discrete math or I will study English literature. I will not study discrete math. Therefore, I will study English literature." Determine whether the argument is valid.',
    options: [
      { letter: "A", text: "Valid" },
      { letter: "B", text: "Invalid" },
    ],
    correctLetter: "A",
    correctText: "Valid",
    explanation:
      "إذا كانت إحدى العبارتين صحيحة (سأدرس الرياضيات المتقطعة أو الأدب الإنجليزي) ونُفيت الأولى، تلزم الثانية؛ وهذه قاعدة الفصل المنطقي.",
  },
  {
    id: 19,
    prompt:
      "Let P(x, y) be the statement xy = 1. What is the truth value of ∀ x ∃ y P(x, y) if the domain is all integer numbers?",
    options: [
      { letter: "", text: "True" },
      { letter: "", text: "False" },
    ],
    correctLetter: "",
    correctText: "False",
    explanation:
      "عند x = 0 لا يوجد عدد صحيح y يجعل xy = 1؛ لذلك لا تتحقق العبارة لكل x.",
  },
  {
    id: 20,
    prompt:
      'Consider the argument: "If you have a current password, then you can log onto the network. You have a current password. Therefore, you can not log onto the network." Determine whether the argument is valid.',
    options: [
      { letter: "A", text: "Invalid" },
      { letter: "B", text: "Valid" },
    ],
    correctLetter: "A",
    correctText: "Invalid",
    explanation:
      "المقدمتان تقولان إن كلمة المرور الحالية تتيح تسجيل الدخول، ولا تستنتجان عدم القدرة عليه؛ لذا فالنتيجة لا تتبع.",
  },
];
