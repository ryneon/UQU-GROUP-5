import {
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const practiceSessions = mysqlTable("practice_sessions", {
  sessionId: varchar("sessionId", { length: 36 }).primaryKey(),
  normalizedName: varchar("normalizedName", { length: 64 }).notNull(),
  displayName: varchar("displayName", { length: 32 }).notNull(),
  sessionKind: mysqlEnum("sessionKind", ["leaderboard", "grade_estimate"]).default("leaderboard").notNull(),
  questionKeys: json("questionKeys").$type<string[]>().notNull(),
  answers: json("answers").$type<Record<string, number>>(),
  startedAt: timestamp("startedAt").notNull(),
  completedAt: timestamp("completedAt"),
  score: int("score"),
  elapsedSeconds: int("elapsedSeconds"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PracticeSession = typeof practiceSessions.$inferSelect;

export const leaderboardEntries = mysqlTable("leaderboard_entries", {
  id: int("id").autoincrement().primaryKey(),
  normalizedName: varchar("normalizedName", { length: 64 }).notNull().unique(),
  displayName: varchar("displayName", { length: 32 }).notNull(),
  bestScore: int("bestScore").notNull(),
  bestElapsedSeconds: int("bestElapsedSeconds").notNull(),
  attemptCount: int("attemptCount").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LeaderboardEntry = typeof leaderboardEntries.$inferSelect;
