CREATE TABLE `leaderboard_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`normalizedName` varchar(64) NOT NULL,
	`displayName` varchar(32) NOT NULL,
	`bestScore` int NOT NULL,
	`bestElapsedSeconds` int NOT NULL,
	`attemptCount` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leaderboard_entries_id` PRIMARY KEY(`id`),
	CONSTRAINT `leaderboard_entries_normalizedName_unique` UNIQUE(`normalizedName`)
);
--> statement-breakpoint
CREATE TABLE `practice_sessions` (
	`sessionId` varchar(36) NOT NULL,
	`normalizedName` varchar(64) NOT NULL,
	`displayName` varchar(32) NOT NULL,
	`questionKeys` json NOT NULL,
	`startedAt` timestamp NOT NULL,
	`completedAt` timestamp,
	`score` int,
	`elapsedSeconds` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `practice_sessions_sessionId` PRIMARY KEY(`sessionId`)
);
